const express = require('express');
const router = express.Router();
const {
  obtenerResultados,
  obtenerTablaPosiciones,
  obtenerGoleadores,
  obtenerAsistentes,
  obtenerCalendario,
  obtenerInformacionEquipo,
  obtenerEquipos
} = require('../controllers/hinchaController');

// Rutas públicas para hinchas
router.get('/resultados', obtenerResultados);
router.get('/tabla-posiciones', obtenerTablaPosiciones);
router.get('/goleadores', obtenerGoleadores);
router.get('/asistentes', obtenerAsistentes);
router.get('/calendario', obtenerCalendario);
router.get('/equipos', obtenerEquipos);
router.get('/equipos/:id', obtenerInformacionEquipo);

module.exports = router; 