const express = require('express');
const router = express.Router();
const {
  obtenerTablaPosiciones,
  obtenerEstadisticasEquipo,
  registrarGol,
  registrarTarjeta,
  crearAlineacion,
  actualizarAlineacion,
  confirmarAlineacion,
  obtenerAlineacion
} = require('../controllers/tecnicoController');

// Rutas para gestión de estadísticas y posiciones
router.get('/tabla-posiciones', obtenerTablaPosiciones);
router.get('/estadisticas-equipo/:equipoId', obtenerEstadisticasEquipo);

// Rutas para gestión de partidos
router.post('/partidos/:partidoId/goles', registrarGol);
router.post('/partidos/:partidoId/tarjetas', registrarTarjeta);

// Rutas para gestión de alineaciones
router.post('/alineaciones', crearAlineacion);
router.put('/alineaciones/:id', actualizarAlineacion);
router.post('/alineaciones/:id/confirmar', confirmarAlineacion);
router.get('/alineaciones/partido/:partidoId/equipo/:equipoId', obtenerAlineacion);

module.exports = router; 