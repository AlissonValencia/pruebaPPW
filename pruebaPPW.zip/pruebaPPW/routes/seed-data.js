// Carga las variables de entorno desde el archivo .env
require('dotenv').config();

// Importa la función de conexión a la base de datos
const connectDB = require('./config/campeonatoDB');

// Importa todos los modelos necesarios
// Asegúrate de que las rutas a tus modelos sean correctas (ej. './models/Equipo')
const Equipo = require('./models/Equipo');
const Jugador = require('./models/Jugador'); // Corregido: require('./models/Jugador');
const Partido = require('./models/Partido');
const Alineacion = require('./models/Alineacion');
const Estadistica = require('./models/Estadistica');

// Conecta a la base de datos
connectDB();

// --- VARIABLES PARA ALMACENAR IDs DESPUÉS DE LA INSERCIÓN ---
// Esto es crucial para establecer relaciones entre los documentos.
let elNacionalId, lduId, barcelonaId, emelecId;
let jugadorElNacional1Id, jugadorElNacional2Id, jugadorElNacional3Id;
let jugadorLDU1Id, jugadorLDU2Id, jugadorLDU3Id;
let jugadorBarcelona1Id, jugadorBarcelona2Id, jugadorBarcelona3Id;
let jugadorEmelec1Id, jugadorEmelec2Id, jugadorEmelec3Id;
let partido1Id, partido2Id, partido3Id;


// --- DATOS DE EJEMPLO PARA CADA MODELO ---

// 1. Datos para Equipos (iniciales, las estadísticas se actualizarán después de los partidos)
const equiposData = [
  {
    nombre: 'Club Deportivo El Nacional',
    ciudad: 'Quito',
    fundacion: new Date('1964-06-01'),
    colores: { principal: '#FF0000', secundario: '#FFFFFF' },
    estadio: { nombre: 'Olímpico Atahualpa', capacidad: 35742 },
    directorTecnico: { nombre: 'Ever Hugo Almeida', telefono: '0991234567', email: 'ever.almeida@elnacional.com' },
    estadisticas: { partidosJugados: 0, partidosGanados: 0, partidosEmpatados: 0, partidosPerdidos: 0, golesFavor: 0, golesContra: 0, puntos: 0 },
    activo: true
  },
  {
    nombre: 'Liga Deportiva Universitaria',
    ciudad: 'Quito',
    fundacion: new Date('1918-01-11'),
    colores: { principal: '#FFFFFF', secundario: '#000000' },
    estadio: { nombre: 'Rodrigo Paz Delgado', capacidad: 41575 },
    directorTecnico: { nombre: 'Josep Alcácer', telefono: '0987654321', email: 'josep.alcacer@ldu.com' },
    estadisticas: { partidosJugados: 0, partidosGanados: 0, partidosEmpatados: 0, partidosPerdidos: 0, golesFavor: 0, golesContra: 0, puntos: 0 },
    activo: true
  },
  {
    nombre: 'Barcelona Sporting Club',
    ciudad: 'Guayaquil',
    fundacion: new Date('1925-05-01'),
    colores: { principal: '#FFFF00', secundario: '#000000' },
    estadio: { nombre: 'Monumental Banco Pichincha', capacidad: 57267 },
    directorTecnico: { nombre: 'Diego López', telefono: '0971237890', email: 'diego.lopez@barcelona.com' },
    estadisticas: { partidosJugados: 0, partidosGanados: 0, partidosEmpatados: 0, partidosPerdidos: 0, golesFavor: 0, golesContra: 0, puntos: 0 },
    activo: true
  },
  {
    nombre: 'Club Sport Emelec',
    ciudad: 'Guayaquil',
    fundacion: new Date('1929-04-28'),
    colores: { principal: '#0000FF', secundario: '#FFFFFF' },
    estadio: { nombre: 'George Capwell', capacidad: 40000 },
    directorTecnico: { nombre: 'Hernán Torres', telefono: '0969876543', email: 'hernan.torres@emelec.com' },
    estadisticas: { partidosJugados: 0, partidosGanados: 0, partidosEmpatados: 0, partidosPerdidos: 0, golesFavor: 0, golesContra: 0, puntos: 0 },
    activo: true
  }
];

// 2. Datos para Jugadores (se rellenarán con IDs de Equipo después de insertar Equipos)
let jugadoresData = [];

// 3. Datos para Partidos (se rellenarán con IDs de Equipo y Jugador después de insertarlos)
let partidosData = [];

// 4. Datos para Alineaciones (se rellenarán con IDs de Partido, Equipo y Jugador)
let alineacionesData = [];

// 5. Datos para Estadísticas (se rellenarán con IDs de Jugador y Equipo)
let estadisticasData = [];


/**
 * @desc Función principal para importar todos los datos de ejemplo a la base de datos.
 * Se encarga de eliminar datos existentes y luego insertar nuevos en el orden correcto
 * para manejar las dependencias entre modelos.
 */
const importData = async () => {
  try {
    console.log('Iniciando importación de datos...');

    // --- 1. Limpiar la base de datos (eliminar todos los documentos existentes) ---
    console.log('Limpiando colecciones existentes...');
    await Alineacion.deleteMany();
    await Partido.deleteMany();
    await Jugador.deleteMany();
    await Equipo.deleteMany();
    await Estadistica.deleteMany();
    console.log('Colecciones limpiadas.');

    // --- 2. Insertar Equipos (primero, ya que otros modelos dependen de ellos) ---
    console.log('Insertando equipos...');
    const insertedEquipos = await Equipo.insertMany(equiposData);
    elNacionalId = insertedEquipos.find(e => e.nombre === 'Club Deportivo El Nacional')._id;
    lduId = insertedEquipos.find(e => e.nombre === 'Liga Deportiva Universitaria')._id;
    barcelonaId = insertedEquipos.find(e => e.nombre === 'Barcelona Sporting Club')._id;
    emelecId = insertedEquipos.find(e => e.nombre === 'Club Sport Emelec')._id;
    console.log('Equipos insertados.');

    // --- 3. Preparar y Insertar Jugadores (dependen de Equipos) ---
    console.log('Insertando jugadores...');
    jugadoresData = [
      // Jugadores de El Nacional
      {
        nombre: 'Jorge', apellido: 'Pinos', fechaNacimiento: new Date('1989-02-17'), dni: '1712345678', telefono: '0991111111', email: 'jorge.pinos@elnacional.com', direccion: 'Av. Amazonas N123',
        posicion: 'Portero', numero: 1, pieHabil: 'Derecho', altura: 185, peso: 80, equipo: elNacionalId, estado: 'Activo',
        estadisticas: { partidosJugados: 10, goles: 0, asistencias: 0, tarjetasAmarillas: 1, tarjetasRojas: 0 },
        contactoEmergencia: { nombre: 'María Pinos', relacion: 'Esposa', telefono: '0991111112' }
      },
      {
        nombre: 'Ronny', apellido: 'Carrillo', fechaNacimiento: new Date('1996-06-11'), dni: '1712345679', telefono: '0992222222', email: 'ronny.carrillo@elnacional.com', direccion: 'Calle 5 N456',
        posicion: 'Delantero', numero: 9, pieHabil: 'Derecho', altura: 178, peso: 75, equipo: elNacionalId, estado: 'Activo',
        estadisticas: { partidosJugados: 10, goles: 8, asistencias: 2, tarjetasAmarillas: 2, tarjetasRojas: 0 },
        contactoEmergencia: { nombre: 'Carlos Carrillo', relacion: 'Padre', telefono: '0992222223' }
      },
      {
        nombre: 'Andrés', apellido: 'Micolta', fechaNacimiento: new Date('1999-03-20'), dni: '1712345677', telefono: '0993333333', email: 'andres.micolta@elnacional.com', direccion: 'Av. 6 de Diciembre',
        posicion: 'Defensa', numero: 5, pieHabil: 'Izquierdo', altura: 188, peso: 82, equipo: elNacionalId, estado: 'Activo',
        estadisticas: { partidosJugados: 9, goles: 1, asistencias: 0, tarjetasAmarillas: 3, tarjetasRojas: 0 },
        contactoEmergencia: { nombre: 'Laura Micolta', relacion: 'Madre', telefono: '0993333334' }
      },
      // Jugadores de Liga de Quito
      {
        nombre: 'Alexander', apellido: 'Domínguez', fechaNacimiento: new Date('1987-06-05'), dni: '1712345680', telefono: '0993333333', email: 'alex.dominguez@ldu.com', direccion: 'Av. Occidental S789',
        posicion: 'Portero', numero: 22, pieHabil: 'Derecho', altura: 195, peso: 90, equipo: lduId, estado: 'Activo',
        estadisticas: { partidosJugados: 10, goles: 0, asistencias: 0, tarjetasAmarillas: 0, tarjetasRojas: 0 },
        contactoEmergencia: { nombre: 'Andrea Domínguez', relacion: 'Hermana', telefono: '0993333334' }
      },
      {
        nombre: 'Paolo', apellido: 'Guerrero', fechaNacimiento: new Date('1984-01-01'), dni: '1712345681', telefono: '0994444444', email: 'paolo.guerrero@ldu.com', direccion: 'Calle Principal E123',
        posicion: 'Delantero', numero: 9, pieHabil: 'Derecho', altura: 185, peso: 85, equipo: lduId, estado: 'Activo',
        estadisticas: { partidosJugados: 8, goles: 5, asistencias: 1, tarjetasAmarillas: 3, tarjetasRojas: 0 },
        contactoEmergencia: { nombre: 'Petronila Gonzales', relacion: 'Madre', telefono: '0994444445' }
      },
      {
        nombre: 'Ezequiel', apellido: 'Piovi', fechaNacimiento: new Date('1991-08-20'), dni: '1712345682', telefono: '0995555555', email: 'ezequiel.piovi@ldu.com', direccion: 'Av. Eloy Alfaro N456',
        posicion: 'Mediocampista', numero: 8, pieHabil: 'Derecho', altura: 175, peso: 72, equipo: lduId, estado: 'Activo',
        estadisticas: { partidosJugados: 10, goles: 1, asistencias: 3, tarjetasAmarillas: 5, tarjetasRojas: 0 },
        contactoEmergencia: { nombre: 'Juan Piovi', relacion: 'Hermano', telefono: '0995555556' }
      },
      // Jugadores de Barcelona SC
      {
        nombre: 'Javier', apellido: 'Burrai', fechaNacimiento: new Date('1990-10-09'), dni: '0912345678', telefono: '0995555555', email: 'javier.burrai@barcelona.com', direccion: 'Calle 10 O789',
        posicion: 'Portero', numero: 1, pieHabil: 'Derecho', altura: 189, peso: 85, equipo: barcelonaId, estado: 'Activo',
        estadisticas: { partidosJugados: 10, goles: 0, asistencias: 0, tarjetasAmarillas: 2, tarjetasRojas: 0 },
        contactoEmergencia: { nombre: 'Ana Burrai', relacion: 'Esposa', telefono: '0995555556' }
      },
      {
        nombre: 'Damián', apellido: 'Díaz', fechaNacimiento: new Date('1986-05-01'), dni: '0912345679', telefono: '0996666666', email: 'damian.diaz@barcelona.com', direccion: 'Av. 9 de Octubre 123',
        posicion: 'Mediocampista', numero: 10, pieHabil: 'Derecho', altura: 168, peso: 68, equipo: barcelonaId, estado: 'Activo',
        estadisticas: { partidosJugados: 9, goles: 3, asistencias: 7, tarjetasAmarillas: 4, tarjetasRojas: 1 },
        contactoEmergencia: { nombre: 'María Díaz', relacion: 'Madre', telefono: '0996666667' }
      },
      {
        nombre: 'Francisco', apellido: 'Fydriszewski', fechaNacimiento: new Date('1993-04-25'), dni: '0912345680', telefono: '0997777777', email: 'polaco.f@barcelona.com', direccion: 'Av. del Salado',
        posicion: 'Delantero', numero: 9, pieHabil: 'Derecho', altura: 180, peso: 78, equipo: barcelonaId, estado: 'Activo',
        estadisticas: { partidosJugados: 8, goles: 6, asistencias: 1, tarjetasAmarillas: 1, tarjetasRojas: 0 },
        contactoEmergencia: { nombre: 'Juana Fydriszewski', relacion: 'Hermana', telefono: '0997777778' }
      },
      // Jugadores de Emelec
      {
        nombre: 'Pedro', apellido: 'Ortiz', fechaNacimiento: new Date('1990-07-03'), dni: '0912345682', telefono: '0997777777', email: 'pedro.ortiz@emelec.com', direccion: 'Calle 20 S456',
        posicion: 'Portero', numero: 1, pieHabil: 'Derecho', altura: 188, peso: 82, equipo: emelecId, estado: 'Activo',
        estadisticas: { partidosJugados: 10, goles: 0, asistencias: 0, tarjetasAmarillas: 1, tarjetasRojas: 0 },
        contactoEmergencia: { nombre: 'Juan Ortiz', relacion: 'Hermano', telefono: '0997777778' }
      },
      {
        nombre: 'Miller', apellido: 'Bolaños', fechaNacimiento: new Date('1990-06-01'), dni: '0912345683', telefono: '0998888888', email: 'miller.bolanos@emelec.com', direccion: 'Av. 25 de Julio N789',
        posicion: 'Delantero', numero: 23, pieHabil: 'Derecho', altura: 170, peso: 70, equipo: emelecId, estado: 'Activo',
        estadisticas: { partidosJugados: 7, goles: 4, asistencias: 2, tarjetasAmarillas: 2, tarjetasRojas: 0 },
        contactoEmergencia: { nombre: 'Rosa Bolaños', relacion: 'Madre', telefono: '0998888889' }
      },
      {
        nombre: 'Fernando', apellido: 'León', fechaNacimiento: new Date('1993-04-11'), dni: '0912345684', telefono: '0999999999', email: 'fernando.leon@emelec.com', direccion: 'Calle Principal E101',
        posicion: 'Defensa', numero: 4, pieHabil: 'Izquierdo', altura: 185, peso: 80, equipo: emelecId, estado: 'Activo',
        estadisticas: { partidosJugados: 9, goles: 0, asistencias: 0, tarjetasAmarillas: 4, tarjetasRojas: 1 },
        contactoEmergencia: { nombre: 'Luis León', relacion: 'Padre', telefono: '0999999990' }
      }
    ];
    const insertedJugadores = await Jugador.insertMany(jugadoresData);
    jugadorElNacional1Id = insertedJugadores.find(j => j.nombre === 'Jorge' && j.apellido === 'Pinos')._id;
    jugadorElNacional2Id = insertedJugadores.find(j => j.nombre === 'Ronny' && j.apellido === 'Carrillo')._id;
    jugadorElNacional3Id = insertedJugadores.find(j => j.nombre === 'Andrés' && j.apellido === 'Micolta')._id;

    jugadorLDU1Id = insertedJugadores.find(j => j.nombre === 'Alexander' && j.apellido === 'Domínguez')._id;
    jugadorLDU2Id = insertedJugadores.find(j => j.nombre === 'Paolo' && j.apellido === 'Guerrero')._id;
    jugadorLDU3Id = insertedJugadores.find(j => j.nombre === 'Ezequiel' && j.apellido === 'Piovi')._id;

    jugadorBarcelona1Id = insertedJugadores.find(j => j.nombre === 'Javier' && j.apellido === 'Burrai')._id;
    jugadorBarcelona2Id = insertedJugadores.find(j => j.nombre === 'Damián' && j.apellido === 'Díaz')._id;
    jugadorBarcelona3Id = insertedJugadores.find(j => j.nombre === 'Francisco' && j.apellido === 'Fydriszewski')._id;

    jugadorEmelec1Id = insertedJugadores.find(j => j.nombre === 'Pedro' && j.apellido === 'Ortiz')._id;
    jugadorEmelec2Id = insertedJugadores.find(j => j.nombre === 'Miller' && j.apellido === 'Bolaños')._id;
    jugadorEmelec3Id = insertedJugadores.find(j => j.nombre === 'Fernando' && j.apellido === 'León')._id;
    console.log('Jugadores insertados.');

    // 4. Preparar y Insertar Partidos (dependen de Equipos y Jugadores para eventos)
    console.log('Insertando partidos...');
    partidosData = [
      {
        fecha: new Date('2025-07-20'), hora: '15:00', estadio: 'Olímpico Atahualpa',
        equipoLocal: elNacionalId, equipoVisitante: lduId,
        resultado: { golesLocal: 2, golesVisitante: 1, finalizado: true },
        estado: 'Finalizado',
        arbitro: { nombre: 'Augusto Aragón', telefono: '0990000001' },
        eventos: [
          { tipo: 'Gol', minuto: 20, jugador: jugadorElNacional2Id, equipo: elNacionalId, descripcion: 'Gol de cabeza' },
          { tipo: 'Tarjeta Amarilla', minuto: 35, jugador: jugadorLDU2Id, equipo: lduId, motivo: 'Falta táctica' },
          { tipo: 'Gol', minuto: 45, jugador: jugadorLDU2Id, equipo: lduId, descripcion: 'Gol de penal' },
          { tipo: 'Gol', minuto: 70, jugador: jugadorElNacional2Id, equipo: elNacionalId, descripcion: 'Gol de jugada' },
        ],
        observaciones: 'Partido intenso con muchas faltas', asistencia: 15000, condicionesClimaticas: 'Nublado', temperatura: 18
      },
      {
        fecha: new Date('2025-07-21'), hora: '18:00', estadio: 'Monumental Banco Pichincha',
        equipoLocal: barcelonaId, equipoVisitante: emelecId,
        resultado: { golesLocal: 1, golesVisitante: 1, finalizado: true },
        estado: 'Finalizado',
        arbitro: { nombre: 'Guillermo Guerrero', telefono: '0990000002' },
        eventos: [
          { tipo: 'Gol', minuto: 15, jugador: jugadorBarcelona2Id, equipo: barcelonaId, descripcion: 'Gol de tiro libre' },
          { tipo: 'Tarjeta Roja', minuto: 60, jugador: jugadorEmelec2Id, equipo: emelecId, motivo: 'Doble amarilla' },
          { tipo: 'Gol', minuto: 80, jugador: jugadorEmelec2Id, equipo: emelecId, descripcion: 'Gol de jugada' },
        ],
        observaciones: 'Clásico del Astillero', asistencia: 40000, condicionesClimaticas: 'Soleado', temperatura: 25
      },
      {
        fecha: new Date('2025-07-27'), hora: '15:00', estadio: 'Rodrigo Paz Delgado',
        equipoLocal: lduId, equipoVisitante: barcelonaId,
        resultado: { golesLocal: 0, golesVisitante: 0, finalizado: false }, // Programado
        estado: 'Programado',
        arbitro: { nombre: 'Franklin Congo', telefono: '0990000003' },
        observaciones: 'Próximo partido importante', asistencia: 0, condicionesClimaticas: 'Nublado', temperatura: 17
      }
    ];
    const insertedPartidos = await Partido.insertMany(partidosData);
    partido1Id = insertedPartidos.find(p => p.estadio === 'Olímpico Atahualpa')._id;
    partido2Id = insertedPartidos.find(p => p.estadio === 'Monumental Banco Pichincha')._id;
    partido3Id = insertedPartidos.find(p => p.estadio === 'Rodrigo Paz Delgado')._id;
    console.log('Partidos insertados.');

    // 5. Preparar y Insertar Alineaciones (dependen de Partidos, Equipos, Jugadores)
    console.log('Insertando alineaciones...');
    alineacionesData = [
      {
        partido: partido1Id, equipo: elNacionalId, formacion: '4-4-2',
        jugadores: [
          { jugador: jugadorElNacional1Id, posicion: 'Portero', numero: 1, tipo: 'Titular', orden: 1 },
          { jugador: jugadorElNacional2Id, posicion: 'Delantero Centro', numero: 9, tipo: 'Titular', orden: 10 },
          { jugador: jugadorElNacional3Id, posicion: 'Defensa Central', numero: 5, tipo: 'Titular', orden: 3 }
        ],
        directorTecnico: { nombre: 'Ever Hugo Almeida', telefono: '0991234567' },
        confirmada: true, fechaConfirmacion: new Date('2025-07-19T10:00:00Z')
      },
      {
        partido: partido1Id, equipo: lduId, formacion: '4-3-3',
        jugadores: [
          { jugador: jugadorLDU1Id, posicion: 'Portero', numero: 22, tipo: 'Titular', orden: 1 },
          { jugador: jugadorLDU2Id, posicion: 'Delantero Centro', numero: 9, tipo: 'Titular', orden: 11 },
          { jugador: jugadorLDU3Id, posicion: 'Mediocampista Central', numero: 8, tipo: 'Titular', orden: 6 }
        ],
        directorTecnico: { nombre: 'Josep Alcácer', telefono: '0987654321' },
        confirmada: true, fechaConfirmacion: new Date('2025-07-19T10:30:00Z')
      },
       {
        partido: partido3Id, equipo: lduId, formacion: '4-2-3-1',
        jugadores: [
          { jugador: jugadorLDU1Id, posicion: 'Portero', numero: 22, tipo: 'Titular', orden: 1 },
          { jugador: jugadorLDU2Id, posicion: 'Delantero Centro', numero: 9, tipo: 'Titular', orden: 11 },
          { jugador: jugadorLDU3Id, posicion: 'Mediocampista Defensivo', numero: 8, tipo: 'Titular', orden: 4 }
        ],
        directorTecnico: { nombre: 'Josep Alcácer', telefono: '0987654321' },
        confirmada: false // Aun no confirmada
      }
    ];
    await Alineacion.insertMany(alineacionesData);
    console.log('Alineaciones insertadas.');

    // 6. Preparar y Insertar Estadísticas (dependen de Jugadores y Equipos)
    console.log('Insertando estadísticas generales...');
    estadisticasData = [
      {
        tipo: 'Goleador', temporada: '2025', fechaInicio: new Date('2025-01-01'), fechaFin: new Date('2025-12-31'),
        datos: [
          { jugador: jugadorElNacional2Id, equipo: elNacionalId, goles: 8, partidos: 10, valor: 8 }, // 'valor' para ordenar
          { jugador: jugadorLDU2Id, equipo: lduId, goles: 5, partidos: 8, valor: 5 },
          { jugador: jugadorBarcelona3Id, equipo: barcelonaId, goles: 6, partidos: 8, valor: 6 },
          { jugador: jugadorEmelec2Id, equipo: emelecId, goles: 4, partidos: 7, valor: 4 }
        ],
        configuracion: { ordenarPor: 'goles', orden: 'descendente', limite: 20 },
        activa: true
      },
      {
        tipo: 'Asistente', temporada: '2025', fechaInicio: new Date('2025-01-01'), fechaFin: new Date('2025-12-31'),
        datos: [
          { jugador: jugadorBarcelona2Id, equipo: barcelonaId, asistencias: 7, partidos: 9, valor: 7 },
          { jugador: jugadorElNacional2Id, equipo: elNacionalId, asistencias: 2, partidos: 10, valor: 2 },
          { jugador: jugadorLDU2Id, equipo: lduId, asistencias: 1, partidos: 8, valor: 1 },
          { jugador: jugadorEmelec2Id, equipo: emelecId, asistencias: 2, partidos: 7, valor: 2 }
        ],
        configuracion: { ordenarPor: 'asistencias', orden: 'descendente', limite: 20 },
        activa: true
      },
      {
        tipo: 'Tarjetas', temporada: '2025', fechaInicio: new Date('2025-01-01'), fechaFin: new Date('2025-12-31'),
        datos: [
          { jugador: jugadorBarcelona2Id, equipo: barcelonaId, tarjetasAmarillas: 4, tarjetasRojas: 1, valor: 5 }, // Valor total de tarjetas
          { jugador: jugadorElNacional3Id, equipo: elNacionalId, tarjetasAmarillas: 3, tarjetasRojas: 0, valor: 3 },
          { jugador: jugadorLDU3Id, equipo: lduId, tarjetasAmarillas: 5, tarjetasRojas: 0, valor: 5 },
          { jugador: jugadorEmelec3Id, equipo: emelecId, tarjetasAmarillas: 4, tarjetasRojas: 1, valor: 5 }
        ],
        configuracion: { ordenarPor: 'valor', orden: 'descendente', limite: 20 },
        activa: true
      }
    ];
    await Estadistica.insertMany(estadisticasData);
    console.log('Estadísticas generales insertadas.');

    // 7. Actualizar Estadísticas de Equipos (basado en los partidos insertados)
    console.log('Actualizando estadísticas de equipos...');
    // Para el Nacional (Partido 1: Gana 2-1 vs LDU)
    await Equipo.findByIdAndUpdate(elNacionalId, {
      $inc: {
        'estadisticas.partidosJugados': 1,
        'estadisticas.partidosGanados': 1,
        'estadisticas.golesFavor': 2,
        'estadisticas.golesContra': 1,
        'estadisticas.puntos': 3
      }
    });
    // Para LDU (Partido 1: Pierde 1-2 vs El Nacional)
    await Equipo.findByIdAndUpdate(lduId, {
      $inc: {
        'estadisticas.partidosJugados': 1,
        'estadisticas.partidosPerdidos': 1,
        'estadisticas.golesFavor': 1,
        'estadisticas.golesContra': 2
      }
    });
    // Para Barcelona (Partido 2: Empata 1-1 vs Emelec)
    await Equipo.findByIdAndUpdate(barcelonaId, {
      $inc: {
        'estadisticas.partidosJugados': 1,
        'estadisticas.partidosEmpatados': 1,
        'estadisticas.golesFavor': 1,
        'estadisticas.golesContra': 1,
        'estadisticas.puntos': 1
      }
    });
    // Para Emelec (Partido 2: Empata 1-1 vs Barcelona)
    await Equipo.findByIdAndUpdate(emelecId, {
      $inc: {
        'estadisticas.partidosJugados': 1,
        'estadisticas.partidosEmpatados': 1,
        'estadisticas.golesFavor': 1,
        'estadisticas.golesContra': 1,
        'estadisticas.puntos': 1
      }
    });
    console.log('Estadísticas de equipos actualizadas.');


    console.log('✅ Todos los datos importados con éxito!');
    process.exit(); // Sale del proceso al finalizar.
  } catch (error) {
    console.error(`❌ Error al importar datos: ${error.message}`);
    console.error(error.stack); // Mostrar el stack trace completo para depuración
    process.exit(1); // Sale del proceso con un código de error si falla.
  }
};

/**
 * @desc Elimina todos los datos de la base de datos de todos los modelos.
 */
const deleteData = async () => {
  try {
    console.log('Iniciando eliminación de datos...');
    await Alineacion.deleteMany();
    await Partido.deleteMany();
    await Jugador.deleteMany();
    await Equipo.deleteMany();
    await Estadistica.deleteMany();
    console.log('🗑️ Todos los datos eliminados con éxito!');
    process.exit();
  } catch (error) {
    console.error(`❌ Error al eliminar datos: ${error.message}`);
    console.error(error.stack);
    process.exit(1);
  }
};

// Determina qué función ejecutar basándose en los argumentos de la línea de comandos
// Para importar datos: node seed-data.js -i
// Para eliminar datos: node seed-data.js -d
if (process.argv[2] === '-i') {
  importData();
} else if (process.argv[2] === '-d') {
  deleteData();
} else {
  console.log('Uso: node seed-data.js [-i para importar | -d para eliminar]');
  process.exit(0);
}
