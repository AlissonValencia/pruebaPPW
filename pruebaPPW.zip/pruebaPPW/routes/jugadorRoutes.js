const express = require('express');
const router = express.Router();
const {
  obtenerJugadores,
  obtenerJugador,
  crearJugador,
  actualizarJugador,
  eliminarJugador,
  obtenerEstadisticasJugador,
  verificarAlineacionProximoPartido,
  obtenerJugadoresPorEquipo
} = require('../controllers/jugadorController');

// Rutas públicas (para jugadores consultando sus datos)
router.get('/', obtenerJugadores);
router.get('/:id', obtenerJugador);
router.get('/:id/estadisticas', obtenerEstadisticasJugador);
router.get('/:id/alineacion-proximo-partido', verificarAlineacionProximoPartido);
router.get('/equipo/:equipoId', obtenerJugadoresPorEquipo);

// Rutas privadas (para directores técnicos)
router.post('/', crearJugador);
router.put('/:id', actualizarJugador);
router.delete('/:id', eliminarJugador);

module.exports = router; 