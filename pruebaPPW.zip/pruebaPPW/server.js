const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
require('dotenv').config();

// Importar conexión a base de datos
const connectDB = require('./config/campeonatoDB');

// Importar rutas
const jugadorRoutes = require('./routes/jugadorRoutes');
const tecnicoRoutes = require('./routes/tecnicoRoutes');
const hinchaRoutes = require('./routes/hinchaRoutes');

// Inicializar express
const app = express();

// Conectar a la base de datos
connectDB();

// Configuración de seguridad
app.use(helmet());

// Configuración de CORS
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? ['https://tu-dominio.com'] 
    : ['http://localhost:3000', 'http://localhost:3001'],
  credentials: true
}));

// Configuración de rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutos
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // límite de 100 requests por ventana
  message: {
    success: false,
    message: 'Demasiadas solicitudes desde esta IP, inténtalo de nuevo más tarde.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

app.use('/api/', limiter);

// Middleware para logging
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// Middleware para parsear JSON
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Middleware para manejo de errores de parsing
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({
      success: false,
      message: 'Error en el formato JSON de la solicitud'
    });
  }
  next();
});

// Ruta de prueba
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: '🚀 API de Gestión Deportiva UpScore funcionando correctamente',
    version: '1.0.0',
    environment: process.env.NODE_ENV,
    timestamp: new Date().toISOString(),
    endpoints: {
      jugadores: '/api/jugadores',
      tecnico: '/api/tecnico',
      hincha: '/api/hincha'
    }
  });
});

// Ruta de estado de salud
app.get('/health', (req, res) => {
  res.json({
    success: true,
    message: '✅ Servidor funcionando correctamente',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    environment: process.env.NODE_ENV
  });
});

// Configurar rutas
app.use('/api/jugadores', jugadorRoutes);
app.use('/api/tecnico', tecnicoRoutes);
app.use('/api/hincha', hinchaRoutes);

// Middleware para manejar rutas no encontradas
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    message: `Ruta no encontrada: ${req.originalUrl}`,
    availableRoutes: {
      jugadores: {
        base: '/api/jugadores',
        endpoints: [
          'GET / - Obtener todos los jugadores',
          'GET /:id - Obtener jugador por ID',
          'GET /:id/estadisticas - Obtener estadísticas del jugador',
          'GET /:id/alineacion-proximo-partido - Verificar alineación',
          'GET /equipo/:equipoId - Obtener jugadores por equipo',
          'POST / - Crear nuevo jugador',
          'PUT /:id - Actualizar jugador',
          'DELETE /:id - Eliminar jugador'
        ]
      },
      tecnico: {
        base: '/api/tecnico',
        endpoints: [
          'GET /tabla-posiciones - Obtener tabla de posiciones',
          'GET /estadisticas-equipo/:equipoId - Estadísticas por equipo',
          'POST /partidos/:partidoId/goles - Registrar gol',
          'POST /partidos/:partidoId/tarjetas - Registrar tarjeta',
          'POST /alineaciones - Crear alineación',
          'PUT /alineaciones/:id - Actualizar alineación',
          'POST /alineaciones/:id/confirmar - Confirmar alineación',
          'GET /alineaciones/partido/:partidoId/equipo/:equipoId - Obtener alineación'
        ]
      },
      hincha: {
        base: '/api/hincha',
        endpoints: [
          'GET /resultados - Obtener resultados de partidos',
          'GET /tabla-posiciones - Obtener tabla de posiciones',
          'GET /goleadores - Obtener cuadro de goleadores',
          'GET /asistentes - Obtener cuadro de asistentes',
          'GET /calendario - Obtener calendario de partidos',
          'GET /equipos - Obtener todos los equipos',
          'GET /equipos/:id - Obtener información de equipo'
        ]
      }
    }
  });
});

// Middleware para manejo global de errores
app.use((err, req, res, next) => {
  console.error('Error no manejado:', err);

  // Error de validación de Mongoose
  if (err.name === 'ValidationError') {
    const mensajes = Object.values(err.errors).map(error => error.message);
    return res.status(400).json({
      success: false,
      message: 'Error de validación',
      errors: mensajes
    });
  }

  // Error de duplicación de MongoDB
  if (err.code === 11000) {
    const campo = Object.keys(err.keyValue)[0];
    return res.status(400).json({
      success: false,
      message: `El ${campo} ya existe en la base de datos`
    });
  }

  // Error de cast de MongoDB
  if (err.name === 'CastError') {
    return res.status(400).json({
      success: false,
      message: 'ID inválido'
    });
  }

  // Error genérico
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Error interno del servidor',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// Configuración del puerto
const PORT = process.env.PORT || 3000;

// Iniciar servidor
const server = app.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en puerto ${PORT}`);
  console.log(`📊 Ambiente: ${process.env.NODE_ENV}`);
  console.log(`🗄️  Base de datos: ${process.env.MONGODB_URI}`);
  console.log(`🌐 URL: http://localhost:${PORT}`);
  console.log(`📚 Documentación: http://localhost:${PORT}/health`);
});

// Manejo de señales para cierre graceful
process.on('SIGTERM', () => {
  console.log('🛑 SIGTERM recibido, cerrando servidor...');
  server.close(() => {
    console.log('✅ Servidor cerrado correctamente');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('🛑 SIGINT recibido, cerrando servidor...');
  server.close(() => {
    console.log('✅ Servidor cerrado correctamente');
    process.exit(0);
  });
});

// Manejo de errores no capturados
process.on('unhandledRejection', (err, promise) => {
  console.error('❌ Error no manejado en Promise:', err);
  server.close(() => {
    process.exit(1);
  });
});

process.on('uncaughtException', (err) => {
  console.error('❌ Excepción no capturada:', err);
  server.close(() => {
    process.exit(1);
  });
});

module.exports = app; 