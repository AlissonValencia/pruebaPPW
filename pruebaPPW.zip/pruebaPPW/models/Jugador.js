const mongoose = require('mongoose');

const jugadorSchema = new mongoose.Schema({
  // Información personal
  nombre: {
    type: String,
    required: [true, 'El nombre del jugador es obligatorio'],
    trim: true,
    maxlength: [50, 'El nombre no puede tener más de 50 caracteres']
  },
  apellido: {
    type: String,
    required: [true, 'El apellido del jugador es obligatorio'],
    trim: true,
    maxlength: [50, 'El apellido no puede tener más de 50 caracteres']
  },
  fechaNacimiento: {
    type: Date,
    required: [true, 'La fecha de nacimiento es obligatoria']
  },
  dni: {
    type: String,
    required: [true, 'El DNI es obligatorio'],
    unique: true,
    trim: true
  },
  telefono: {
    type: String,
    required: [true, 'El teléfono es obligatorio'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'El email es obligatorio'],
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Email inválido']
  },
  direccion: {
    type: String,
    required: [true, 'La dirección es obligatoria'],
    trim: true
  },
  
  // Información deportiva
  posicion: {
    type: String,
    required: [true, 'La posición es obligatoria'],
    enum: ['Portero', 'Defensa', 'Mediocampista', 'Delantero'],
    default: 'Mediocampista'
  },
  numero: {
    type: Number,
    required: [true, 'El número de camiseta es obligatorio'],
    min: [1, 'El número debe ser mayor a 0'],
    max: [99, 'El número no puede ser mayor a 99']
  },
  pieHabil: {
    type: String,
    enum: ['Derecho', 'Izquierdo', 'Ambidiestro'],
    default: 'Derecho'
  },
  altura: {
    type: Number,
    min: [100, 'La altura debe ser mayor a 100cm'],
    max: [250, 'La altura no puede ser mayor a 250cm']
  },
  peso: {
    type: Number,
    min: [30, 'El peso debe ser mayor a 30kg'],
    max: [150, 'El peso no puede ser mayor a 150kg']
  },
  
  // Relación con equipo
  equipo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Equipo',
    required: [true, 'El equipo es obligatorio']
  },
  
  // Estado del jugador
  estado: {
    type: String,
    enum: ['Activo', 'Lesionado', 'Suspendido', 'Inactivo'],
    default: 'Activo'
  },
  
  // Estadísticas del jugador
  estadisticas: {
    partidosJugados: {
      type: Number,
      default: 0
    },
    partidosTitular: {
      type: Number,
      default: 0
    },
    partidosSuplente: {
      type: Number,
      default: 0
    },
    minutosJugados: {
      type: Number,
      default: 0
    },
    goles: {
      type: Number,
      default: 0
    },
    asistencias: {
      type: Number,
      default: 0
    },
    tarjetasAmarillas: {
      type: Number,
      default: 0
    },
    tarjetasRojas: {
      type: Number,
      default: 0
    },
    tarjetasRojasDirectas: {
      type: Number,
      default: 0
    },
    lesiones: {
      type: Number,
      default: 0
    },
    calificacionPromedio: {
      type: Number,
      default: 0,
      min: 0,
      max: 10
    }
  },
  
  // Información médica
  grupoSanguineo: {
    type: String,
    enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
  },
  alergias: [{
    type: String,
    trim: true
  }],
  condicionesMedicas: [{
    tipo: {
      type: String,
      enum: ['Lesión', 'Enfermedad', 'Condición Crónica', 'Otro']
    },
    descripcion: String,
    fechaInicio: Date,
    fechaFin: Date,
    activa: {
      type: Boolean,
      default: true
    }
  }],
  
  // Información de contacto de emergencia
  contactoEmergencia: {
    nombre: {
      type: String,
      required: [true, 'El nombre del contacto de emergencia es obligatorio']
    },
    relacion: {
      type: String,
      required: [true, 'La relación con el contacto de emergencia es obligatoria']
    },
    telefono: {
      type: String,
      required: [true, 'El teléfono del contacto de emergencia es obligatorio']
    }
  },
  
  activo: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual para el nombre completo
jugadorSchema.virtual('nombreCompleto').get(function() {
  return `${this.nombre} ${this.apellido}`;
});

// Virtual para calcular la edad
jugadorSchema.virtual('edad').get(function() {
  const hoy = new Date();
  const fechaNac = new Date(this.fechaNacimiento);
  let edad = hoy.getFullYear() - fechaNac.getFullYear();
  const mes = hoy.getMonth() - fechaNac.getMonth();
  if (mes < 0 || (mes === 0 && hoy.getDate() < fechaNac.getDate())) {
    edad--;
  }
  return edad;
});

// Virtual para calcular el promedio de minutos por partido
jugadorSchema.virtual('minutosPorPartido').get(function() {
  if (this.estadisticas.partidosJugados === 0) return 0;
  return Math.round(this.estadisticas.minutosJugados / this.estadisticas.partidosJugados);
});

// Virtual para calcular la efectividad (goles + asistencias por partido)
jugadorSchema.virtual('efectividad').get(function() {
  if (this.estadisticas.partidosJugados === 0) return 0;
  return ((this.estadisticas.goles + this.estadisticas.asistencias) / this.estadisticas.partidosJugados).toFixed(2);
});

// Índices para optimizar consultas
jugadorSchema.index({ nombre: 1, apellido: 1 });
jugadorSchema.index({ dni: 1 });
jugadorSchema.index({ equipo: 1 });
jugadorSchema.index({ posicion: 1 });
jugadorSchema.index({ estado: 1 });
jugadorSchema.index({ 'estadisticas.goles': -1 });
jugadorSchema.index({ 'estadisticas.asistencias': -1 });

module.exports = mongoose.model('Jugador', jugadorSchema); 