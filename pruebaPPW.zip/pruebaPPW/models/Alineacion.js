const mongoose = require('mongoose');

const alineacionSchema = new mongoose.Schema({
  // Información básica
  partido: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Partido',
    required: [true, 'El partido es obligatorio']
  },
  equipo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Equipo',
    required: [true, 'El equipo es obligatorio']
  },
  
  // Formación táctica
  formacion: {
    type: String,
    required: [true, 'La formación es obligatoria'],
    enum: ['4-4-2', '4-3-3', '3-5-2', '4-2-3-1', '3-4-3', '5-3-2', '4-1-4-1', '3-6-1', 'Otro'],
    default: '4-4-2'
  },
  
  // Jugadores en la alineación
  jugadores: [{
    jugador: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Jugador',
      required: true
    },
    posicion: {
      type: String,
      enum: ['Portero', 'Defensa Central', 'Lateral Derecho', 'Lateral Izquierdo', 'Mediocampista Defensivo', 'Mediocampista Central', 'Mediocampista Ofensivo', 'Extremo Derecho', 'Extremo Izquierdo', 'Delantero Centro', 'Segundo Delantero'],
      required: true
    },
    numero: {
      type: Number,
      required: true,
      min: [1, 'El número debe ser mayor a 0'],
      max: [99, 'El número no puede ser mayor a 99']
    },
    tipo: {
      type: String,
      enum: ['Titular', 'Suplente'],
      required: true,
      default: 'Titular'
    },
    orden: {
      type: Number,
      required: true,
      min: [1, 'El orden debe ser mayor a 0']
    }
  }],
  
  // Información adicional
  observaciones: {
    type: String,
    trim: true
  },
  
  // Estado de la alineación
  confirmada: {
    type: Boolean,
    default: false
  },
  fechaCreacion: {
    type: Date,
    default: Date.now
  },
  fechaConfirmacion: {
    type: Date
  },
  
  // Información del director técnico
  directorTecnico: {
    nombre: {
      type: String,
      required: [true, 'El nombre del director técnico es obligatorio']
    },
    telefono: {
      type: String,
      required: [true, 'El teléfono del director técnico es obligatorio']
    }
  },
  
  activo: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual para obtener solo titulares
alineacionSchema.virtual('titulares').get(function() {
  return this.jugadores.filter(j => j.tipo === 'Titular').sort((a, b) => a.orden - b.orden);
});

// Virtual para obtener solo suplentes
alineacionSchema.virtual('suplentes').get(function() {
  return this.jugadores.filter(j => j.tipo === 'Suplente').sort((a, b) => a.orden - b.orden);
});

// Virtual para obtener el número total de jugadores
alineacionSchema.virtual('totalJugadores').get(function() {
  return this.jugadores.length;
});

// Virtual para obtener el número de titulares
alineacionSchema.virtual('totalTitulares').get(function() {
  return this.titulares.length;
});

// Virtual para obtener el número de suplentes
alineacionSchema.virtual('totalSuplentes').get(function() {
  return this.suplentes.length;
});

// Método para agregar jugador a la alineación
alineacionSchema.methods.agregarJugador = function(jugadorId, posicion, numero, tipo = 'Titular') {
  const orden = this.jugadores.length + 1;
  
  // Verificar que el jugador no esté ya en la alineación
  const jugadorExistente = this.jugadores.find(j => j.jugador.toString() === jugadorId.toString());
  if (jugadorExistente) {
    throw new Error('El jugador ya está en la alineación');
  }
  
  // Verificar que el número no esté ocupado
  const numeroOcupado = this.jugadores.find(j => j.numero === numero);
  if (numeroOcupado) {
    throw new Error('El número ya está ocupado por otro jugador');
  }
  
  this.jugadores.push({
    jugador: jugadorId,
    posicion,
    numero,
    tipo,
    orden
  });
  
  return this;
};

// Método para remover jugador de la alineación
alineacionSchema.methods.removerJugador = function(jugadorId) {
  const index = this.jugadores.findIndex(j => j.jugador.toString() === jugadorId.toString());
  if (index === -1) {
    throw new Error('El jugador no está en la alineación');
  }
  
  this.jugadores.splice(index, 1);
  
  // Reordenar los jugadores restantes
  this.jugadores.forEach((jugador, index) => {
    jugador.orden = index + 1;
  });
  
  return this;
};

// Método para cambiar tipo de jugador (titular/suplente)
alineacionSchema.methods.cambiarTipoJugador = function(jugadorId, nuevoTipo) {
  const jugador = this.jugadores.find(j => j.jugador.toString() === jugadorId.toString());
  if (!jugador) {
    throw new Error('El jugador no está en la alineación');
  }
  
  jugador.tipo = nuevoTipo;
  return this;
};

// Método para confirmar la alineación
alineacionSchema.methods.confirmar = function() {
  if (this.titulares.length < 11) {
    throw new Error('Debe haber al menos 11 titulares para confirmar la alineación');
  }
  
  this.confirmada = true;
  this.fechaConfirmacion = new Date();
  return this;
};

// Índices para optimizar consultas
alineacionSchema.index({ partido: 1 });
alineacionSchema.index({ equipo: 1 });
alineacionSchema.index({ confirmada: 1 });
alineacionSchema.index({ fechaCreacion: -1 });

module.exports = mongoose.model('Alineacion', alineacionSchema); 