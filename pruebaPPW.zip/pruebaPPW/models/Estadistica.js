const mongoose = require('mongoose');

const estadisticaSchema = new mongoose.Schema({
  // Información básica
  tipo: {
    type: String,
    enum: ['Goleador', 'Asistente', 'Tarjetas', 'Lesiones', 'Minutos', 'Calificaciones'],
    required: [true, 'El tipo de estadística es obligatorio']
  },
  
  // Período de la estadística
  temporada: {
    type: String,
    required: [true, 'La temporada es obligatoria'],
    trim: true
  },
  
  // Fechas de inicio y fin del período
  fechaInicio: {
    type: Date,
    required: [true, 'La fecha de inicio es obligatoria']
  },
  fechaFin: {
    type: Date,
    required: [true, 'La fecha de fin es obligatoria']
  },
  
  // Datos de la estadística
  datos: [{
    jugador: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Jugador',
      required: true
    },
    equipo: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Equipo',
      required: true
    },
    valor: {
      type: Number,
      required: true,
      default: 0
    },
    partidos: {
      type: Number,
      default: 0
    },
    minutos: {
      type: Number,
      default: 0
    },
    // Para goleadores
    goles: {
      type: Number,
      default: 0
    },
    // Para asistentes
    asistencias: {
      type: Number,
      default: 0
    },
    // Para tarjetas
    tarjetasAmarillas: {
      type: Number,
      default: 0
    },
    tarjetasRojas: {
      type: Number,
      default: 0
    },
    tarjetasRojasDirectas: {
      type: Number,
      default: 0
    },
    // Para lesiones
    lesiones: {
      type: Number,
      default: 0
    },
    diasLesionado: {
      type: Number,
      default: 0
    },
    // Para calificaciones
    calificacionPromedio: {
      type: Number,
      default: 0,
      min: 0,
      max: 10
    },
    partidosCalificados: {
      type: Number,
      default: 0
    }
  }],
  
  // Configuración de la estadística
  configuracion: {
    ordenarPor: {
      type: String,
      enum: ['valor', 'goles', 'asistencias', 'tarjetasAmarillas', 'tarjetasRojas', 'lesiones', 'minutos', 'calificacionPromedio'],
      default: 'valor'
    },
    orden: {
      type: String,
      enum: ['ascendente', 'descendente'],
      default: 'descendente'
    },
    limite: {
      type: Number,
      default: 10,
      min: [1, 'El límite debe ser mayor a 0'],
      max: [100, 'El límite no puede ser mayor a 100']
    }
  },
  
  // Estado de la estadística
  activa: {
    type: Boolean,
    default: true
  },
  
  // Información de actualización
  ultimaActualizacion: {
    type: Date,
    default: Date.now
  },
  
  activo: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual para obtener los datos ordenados
estadisticaSchema.virtual('datosOrdenados').get(function() {
  const { ordenarPor, orden, limite } = this.configuracion;
  
  let datosOrdenados = [...this.datos];
  
  // Ordenar por el campo especificado
  datosOrdenados.sort((a, b) => {
    let valorA = a[ordenarPor] || 0;
    let valorB = b[ordenarPor] || 0;
    
    if (orden === 'ascendente') {
      return valorA - valorB;
    } else {
      return valorB - valorA;
    }
  });
  
  // Aplicar límite
  return datosOrdenados.slice(0, limite);
});

// Virtual para obtener el total de registros
estadisticaSchema.virtual('totalRegistros').get(function() {
  return this.datos.length;
});

// Método para agregar o actualizar dato
estadisticaSchema.methods.agregarDato = function(jugadorId, equipoId, datos) {
  const index = this.datos.findIndex(d => d.jugador.toString() === jugadorId.toString());
  
  if (index !== -1) {
    // Actualizar dato existente
    this.datos[index] = { ...this.datos[index], ...datos };
  } else {
    // Agregar nuevo dato
    this.datos.push({
      jugador: jugadorId,
      equipo: equipoId,
      ...datos
    });
  }
  
  this.ultimaActualizacion = new Date();
  return this;
};

// Método para remover dato
estadisticaSchema.methods.removerDato = function(jugadorId) {
  const index = this.datos.findIndex(d => d.jugador.toString() === jugadorId.toString());
  
  if (index !== -1) {
    this.datos.splice(index, 1);
    this.ultimaActualizacion = new Date();
  }
  
  return this;
};

// Método para actualizar configuración
estadisticaSchema.methods.actualizarConfiguracion = function(nuevaConfiguracion) {
  this.configuracion = { ...this.configuracion, ...nuevaConfiguracion };
  this.ultimaActualizacion = new Date();
  return this;
};

// Método estático para crear estadística de goleadores
estadisticaSchema.statics.crearGoleadores = function(temporada, fechaInicio, fechaFin) {
  return new this({
    tipo: 'Goleador',
    temporada,
    fechaInicio,
    fechaFin,
    configuracion: {
      ordenarPor: 'goles',
      orden: 'descendente',
      limite: 20
    }
  });
};

// Método estático para crear estadística de asistentes
estadisticaSchema.statics.crearAsistentes = function(temporada, fechaInicio, fechaFin) {
  return new this({
    tipo: 'Asistente',
    temporada,
    fechaInicio,
    fechaFin,
    configuracion: {
      ordenarPor: 'asistencias',
      orden: 'descendente',
      limite: 20
    }
  });
};

// Método estático para crear estadística de tarjetas
estadisticaSchema.statics.crearTarjetas = function(temporada, fechaInicio, fechaFin) {
  return new this({
    tipo: 'Tarjetas',
    temporada,
    fechaInicio,
    fechaFin,
    configuracion: {
      ordenarPor: 'tarjetasAmarillas',
      orden: 'descendente',
      limite: 20
    }
  });
};

// Índices para optimizar consultas
estadisticaSchema.index({ tipo: 1 });
estadisticaSchema.index({ temporada: 1 });
estadisticaSchema.index({ fechaInicio: 1, fechaFin: 1 });
estadisticaSchema.index({ activa: 1 });
estadisticaSchema.index({ ultimaActualizacion: -1 });

module.exports = mongoose.model('Estadistica', estadisticaSchema); 