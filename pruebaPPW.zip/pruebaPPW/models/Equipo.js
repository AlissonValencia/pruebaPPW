const mongoose = require('mongoose'); // Solo se necesita importar mongoose aquí

// Define el esquema para el modelo Equipo.
const equipoSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: [true, 'El nombre del equipo es obligatorio'],
    trim: true, // Elimina espacios en blanco al principio y al final
    maxlength: [50, 'El nombre no puede tener más de 50 caracteres']
  },
  ciudad: {
    type: String,
    required: [true, 'La ciudad es obligatoria'],
    trim: true
  },
  fundacion: {
    type: Date,
    required: [true, 'La fecha de fundación es obligatoria']
  },
  colores: {
    principal: {
      type: String,
      required: [true, 'El color principal es obligatorio']
    },
    secundario: {
      type: String,
      required: [true, 'El color secundario es obligatorio']
    }
  },
  estadio: {
    nombre: {
      type: String,
      required: [true, 'El nombre del estadio es obligatorio']
    },
    capacidad: {
      type: Number,
      required: [true, 'La capacidad del estadio es obligatoria']
    }
  },
  directorTecnico: {
    nombre: {
      type: String,
      required: [true, 'El nombre del director técnico es obligatorio']
    },
    telefono: {
      type: String,
      required: [true, 'El teléfono del director técnico es obligatorio']
    },
    email: {
      type: String,
      required: [true, 'El email del director técnico es obligatorio'],
      match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Email inválido']
    }
  },
  // Estadísticas del equipo, con valores predeterminados de 0.
  estadisticas: {
    partidosJugados: {
      type: Number,
      default: 0
    },
    partidosGanados: {
      type: Number,
      default: 0
    },
    partidosEmpatados: {
      type: Number,
      default: 0
    },
    partidosPerdidos: {
      type: Number,
      default: 0
    },
    golesFavor: {
      type: Number,
      default: 0
    },
    golesContra: {
      type: Number,
      default: 0
    },
    puntos: {
      type: Number,
      default: 0
    }
  },
  activo: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true, // Agrega campos createdAt y updatedAt automáticamente
  toJSON: { virtuals: true }, // Incluye campos virtuales cuando se convierte a JSON
  toObject: { virtuals: true } // Incluye campos virtuales cuando se convierte a objeto JavaScript
});

// Virtual para calcular la diferencia de goles.
// No se almacena en la DB, se calcula al solicitar el documento.
equipoSchema.virtual('diferenciaGoles').get(function() {
  return this.estadisticas.golesFavor - this.estadisticas.golesContra;
});

// Virtual para calcular el porcentaje de victorias.
// Maneja el caso de división por cero si no hay partidos jugados.
equipoSchema.virtual('porcentajeVictorias').get(function() {
  if (this.estadisticas.partidosJugados === 0) return 0;
  return ((this.estadisticas.partidosGanados / this.estadisticas.partidosJugados) * 100).toFixed(2);
});

// Índices para optimizar consultas en la base de datos.
// Mejora el rendimiento de las búsquedas por nombre, ciudad y estadísticas.
equipoSchema.index({ nombre: 1 });
equipoSchema.index({ ciudad: 1 });
equipoSchema.index({ 'estadisticas.puntos': -1, 'estadisticas.diferenciaGoles': -1 });

// Exporta el modelo 'Equipo' para que pueda ser utilizado en otros archivos.
module.exports = mongoose.model('Equipo', equipoSchema);
