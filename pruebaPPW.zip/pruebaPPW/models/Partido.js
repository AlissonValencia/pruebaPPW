const mongoose = require('mongoose');

const partidoSchema = new mongoose.Schema({
  // Información básica del partido
  fecha: {
    type: Date,
    required: [true, 'La fecha del partido es obligatoria']
  },
  hora: {
    type: String,
    required: [true, 'La hora del partido es obligatoria'],
    match: [/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Formato de hora inválido (HH:MM)']
  },
  estadio: {
    type: String,
    required: [true, 'El estadio es obligatorio'],
    trim: true
  },
  
  // Equipos participantes
  equipoLocal: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Equipo',
    required: [true, 'El equipo local es obligatorio']
  },
  equipoVisitante: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Equipo',
    required: [true, 'El equipo visitante es obligatorio']
  },
  
  // Resultado del partido
  resultado: {
    golesLocal: {
      type: Number,
      default: 0,
      min: [0, 'Los goles no pueden ser negativos']
    },
    golesVisitante: {
      type: Number,
      default: 0,
      min: [0, 'Los goles no pueden ser negativos']
    },
    finalizado: {
      type: Boolean,
      default: false
    },
    tiempoExtra: {
      type: Boolean,
      default: false
    },
    penales: {
      local: {
        type: Number,
        default: 0,
        min: [0, 'Los penales no pueden ser negativos']
      },
      visitante: {
        type: Number,
        default: 0,
        min: [0, 'Los penales no pueden ser negativos']
      }
    }
  },
  
  // Estado del partido
  estado: {
    type: String,
    enum: ['Programado', 'En Curso', 'Finalizado', 'Cancelado', 'Suspendido'],
    default: 'Programado'
  },
  
  // Información del árbitro
  arbitro: {
    nombre: {
      type: String,
      required: [true, 'El nombre del árbitro es obligatorio'],
      trim: true
    },
    telefono: {
      type: String,
      trim: true
    }
  },
  
  // Eventos del partido
  eventos: [{
    tipo: {
      type: String,
      enum: ['Gol', 'Tarjeta Amarilla', 'Tarjeta Roja', 'Tarjeta Roja Directa', 'Lesión', 'Sustitución', 'Otro'],
      required: true
    },
    minuto: {
      type: Number,
      required: true,
      min: [1, 'El minuto debe ser mayor a 0'],
      max: [120, 'El minuto no puede ser mayor a 120']
    },
    jugador: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Jugador',
      required: true
    },
    equipo: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Equipo',
      required: true
    },
    descripcion: {
      type: String,
      trim: true
    },
    // Para goles
    asistencia: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Jugador'
    },
    // Para tarjetas
    motivo: {
      type: String,
      trim: true
    },
    // Para sustituciones
    jugadorEntra: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Jugador'
    },
    jugadorSale: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Jugador'
    }
  }],
  
  // Alineaciones
  alineacionLocal: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Alineacion'
  },
  alineacionVisitante: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Alineacion'
  },
  
  // Información adicional
  observaciones: {
    type: String,
    trim: true
  },
  asistencia: {
    type: Number,
    min: [0, 'La asistencia no puede ser negativa']
  },
  condicionesClimaticas: {
    type: String,
    enum: ['Soleado', 'Nublado', 'Lluvioso', 'Nevado', 'Ventoso']
  },
  temperatura: {
    type: Number
  },
  
  // Estadísticas del partido
  estadisticas: {
    posesionLocal: {
      type: Number,
      min: [0, 'La posesión no puede ser menor a 0'],
      max: [100, 'La posesión no puede ser mayor a 100']
    },
    posesionVisitante: {
      type: Number,
      min: [0, 'La posesión no puede ser menor a 0'],
      max: [100, 'La posesión no puede ser mayor a 100']
    },
    tirosLocal: {
      type: Number,
      default: 0,
      min: [0, 'Los tiros no pueden ser negativos']
    },
    tirosVisitante: {
      type: Number,
      default: 0,
      min: [0, 'Los tiros no pueden ser negativos']
    },
    tirosPuertaLocal: {
      type: Number,
      default: 0,
      min: [0, 'Los tiros a puerta no pueden ser negativos']
    },
    tirosPuertaVisitante: {
      type: Number,
      default: 0,
      min: [0, 'Los tiros a puerta no pueden ser negativos']
    },
    faltasLocal: {
      type: Number,
      default: 0,
      min: [0, 'Las faltas no pueden ser negativas']
    },
    faltasVisitante: {
      type: Number,
      default: 0,
      min: [0, 'Las faltas no pueden ser negativas']
    },
    cornersLocal: {
      type: Number,
      default: 0,
      min: [0, 'Los corners no pueden ser negativos']
    },
    cornersVisitante: {
      type: Number,
      default: 0,
      min: [0, 'Los corners no pueden ser negativos']
    }
  },
  
  activo: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual para obtener el resultado formateado
partidoSchema.virtual('resultadoFormateado').get(function() {
  if (!this.resultado.finalizado) return 'Pendiente';
  return `${this.resultado.golesLocal} - ${this.resultado.golesVisitante}`;
});

// Virtual para determinar el ganador
partidoSchema.virtual('ganador').get(function() {
  if (!this.resultado.finalizado) return null;
  
  if (this.resultado.golesLocal > this.resultado.golesVisitante) {
    return this.equipoLocal;
  } else if (this.resultado.golesVisitante > this.resultado.golesLocal) {
    return this.equipoVisitante;
  } else {
    return 'Empate';
  }
});

// Virtual para verificar si es partido local o visitante para un equipo
partidoSchema.methods.esLocal = function(equipoId) {
  return this.equipoLocal.toString() === equipoId.toString();
};

partidoSchema.methods.esVisitante = function(equipoId) {
  return this.equipoVisitante.toString() === equipoId.toString();
};

// Virtual para obtener el equipo contrario
partidoSchema.methods.getEquipoContrario = function(equipoId) {
  if (this.equipoLocal.toString() === equipoId.toString()) {
    return this.equipoVisitante;
  } else if (this.equipoVisitante.toString() === equipoId.toString()) {
    return this.equipoLocal;
  }
  return null;
};

// Índices para optimizar consultas
partidoSchema.index({ fecha: 1 });
partidoSchema.index({ equipoLocal: 1 });
partidoSchema.index({ equipoVisitante: 1 });
partidoSchema.index({ estado: 1 });
partidoSchema.index({ 'resultado.finalizado': 1 });
partidoSchema.index({ fecha: 1, hora: 1 });

module.exports = mongoose.model('Partido', partidoSchema); 