const mongoose = require('mongoose');
require('dotenv').config();

// Importar modelos
const Equipo = require('./models/Equipo');
const Jugador = require('./models/Jugador');
const Partido = require('./models/Partido');
const Alineacion = require('./models/Alineacion');

// Conectar a MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('✅ Conectado a MongoDB para insertar datos de prueba');
  } catch (error) {
    console.error('❌ Error conectando a MongoDB:', error.message);
    process.exit(1);
  }
};

// Datos de prueba
const equiposData = [
  {
    nombre: 'Real Madrid Amateur',
    ciudad: 'Madrid',
    fundacion: new Date('2020-01-15'),
    colores: {
      principal: 'Blanco',
      secundario: 'Dorado'
    },
    estadio: {
      nombre: 'Estadio Municipal de Madrid',
      capacidad: 5000
    },
    directorTecnico: {
      nombre: 'Carlos Rodríguez',
      telefono: '912345678',
      email: 'carlos.rodriguez@realmadrid.com'
    },
    estadisticas: {
      partidosJugados: 8,
      partidosGanados: 6,
      partidosEmpatados: 1,
      partidosPerdidos: 1,
      golesFavor: 18,
      golesContra: 8,
      puntos: 19
    }
  },
  {
    nombre: 'Barcelona Amateur',
    ciudad: 'Barcelona',
    fundacion: new Date('2019-03-20'),
    colores: {
      principal: 'Azul',
      secundario: 'Granate'
    },
    estadio: {
      nombre: 'Camp Nou Amateur',
      capacidad: 4500
    },
    directorTecnico: {
      nombre: 'José Martínez',
      telefono: '934567890',
      email: 'jose.martinez@barcelona.com'
    },
    estadisticas: {
      partidosJugados: 8,
      partidosGanados: 5,
      partidosEmpatados: 2,
      partidosPerdidos: 1,
      golesFavor: 15,
      golesContra: 7,
      puntos: 17
    }
  },
  {
    nombre: 'Atlético Madrid Amateur',
    ciudad: 'Madrid',
    fundacion: new Date('2021-06-10'),
    colores: {
      principal: 'Rojo',
      secundario: 'Blanco'
    },
    estadio: {
      nombre: 'Estadio Metropolitano Amateur',
      capacidad: 4000
    },
    directorTecnico: {
      nombre: 'Miguel López',
      telefono: '918765432',
      email: 'miguel.lopez@atletico.com'
    },
    estadisticas: {
      partidosJugados: 8,
      partidosGanados: 4,
      partidosEmpatados: 3,
      partidosPerdidos: 1,
      golesFavor: 12,
      golesContra: 9,
      puntos: 15
    }
  }
];

const jugadoresData = [
  // Real Madrid Amateur
  {
    nombre: 'Luis',
    apellido: 'García',
    fechaNacimiento: new Date('1995-05-15'),
    dni: '12345678A',
    telefono: '612345678',
    email: 'luis.garcia@email.com',
    direccion: 'Calle Mayor 123, Madrid',
    posicion: 'Delantero',
    numero: 9,
    pieHabil: 'Derecho',
    altura: 180,
    peso: 75,
    estado: 'Activo',
    estadisticas: {
      partidosJugados: 8,
      partidosTitular: 7,
      partidosSuplente: 1,
      minutosJugados: 720,
      goles: 8,
      asistencias: 3,
      tarjetasAmarillas: 1,
      tarjetasRojas: 0,
      calificacionPromedio: 8.5
    },
    grupoSanguineo: 'O+',
    alergias: [],
    contactoEmergencia: {
      nombre: 'María García',
      relacion: 'Madre',
      telefono: '698765432'
    }
  },
  {
    nombre: 'Carlos',
    apellido: 'López',
    fechaNacimiento: new Date('1993-08-22'),
    dni: '23456789B',
    telefono: '623456789',
    email: 'carlos.lopez@email.com',
    direccion: 'Avenida Principal 456, Madrid',
    posicion: 'Mediocampista',
    numero: 10,
    pieHabil: 'Derecho',
    altura: 175,
    peso: 70,
    estado: 'Activo',
    estadisticas: {
      partidosJugados: 8,
      partidosTitular: 8,
      partidosSuplente: 0,
      minutosJugados: 720,
      goles: 3,
      asistencias: 8,
      tarjetasAmarillas: 2,
      tarjetasRojas: 0,
      calificacionPromedio: 8.2
    },
    grupoSanguineo: 'A+',
    alergias: [],
    contactoEmergencia: {
      nombre: 'Ana López',
      relacion: 'Esposa',
      telefono: '687654321'
    }
  },
  // Barcelona Amateur
  {
    nombre: 'David',
    apellido: 'Martínez',
    fechaNacimiento: new Date('1994-12-03'),
    dni: '34567890C',
    telefono: '634567890',
    email: 'david.martinez@email.com',
    direccion: 'Carrer de la Pau 789, Barcelona',
    posicion: 'Delantero',
    numero: 11,
    pieHabil: 'Izquierdo',
    altura: 178,
    peso: 72,
    estado: 'Activo',
    estadisticas: {
      partidosJugados: 8,
      partidosTitular: 8,
      partidosSuplente: 0,
      minutosJugados: 720,
      goles: 7,
      asistencias: 4,
      tarjetasAmarillas: 1,
      tarjetasRojas: 0,
      calificacionPromedio: 8.0
    },
    grupoSanguineo: 'B+',
    alergias: [],
    contactoEmergencia: {
      nombre: 'Carmen Martínez',
      relacion: 'Madre',
      telefono: '676543210'
    }
  },
  {
    nombre: 'Javier',
    apellido: 'Fernández',
    fechaNacimiento: new Date('1992-03-18'),
    dni: '45678901D',
    telefono: '645678901',
    email: 'javier.fernandez@email.com',
    direccion: 'Passeig de Gràcia 321, Barcelona',
    posicion: 'Portero',
    numero: 1,
    pieHabil: 'Derecho',
    altura: 185,
    peso: 80,
    estado: 'Activo',
    estadisticas: {
      partidosJugados: 8,
      partidosTitular: 8,
      partidosSuplente: 0,
      minutosJugados: 720,
      goles: 0,
      asistencias: 0,
      tarjetasAmarillas: 0,
      tarjetasRojas: 0,
      calificacionPromedio: 7.8
    },
    grupoSanguineo: 'AB+',
    alergias: [],
    contactoEmergencia: {
      nombre: 'Isabel Fernández',
      relacion: 'Esposa',
      telefono: '665432109'
    }
  }
];

// Función para insertar datos
const insertarDatos = async () => {
  try {
    // Limpiar datos existentes
    await Equipo.deleteMany({});
    await Jugador.deleteMany({});
    await Partido.deleteMany({});
    await Alineacion.deleteMany({});
    
    console.log('🗑️ Datos existentes eliminados');

    // Insertar equipos
    const equipos = await Equipo.insertMany(equiposData);
    console.log(`✅ ${equipos.length} equipos insertados`);

    // Asignar equipos a jugadores
    const jugadoresConEquipos = jugadoresData.map((jugador, index) => {
      if (index < 2) {
        jugador.equipo = equipos[0]._id; // Real Madrid
      } else {
        jugador.equipo = equipos[1]._id; // Barcelona
      }
      return jugador;
    });

    // Insertar jugadores
    const jugadores = await Jugador.insertMany(jugadoresConEquipos);
    console.log(`✅ ${jugadores.length} jugadores insertados`);

    // Crear partidos de ejemplo
    const partidosData = [
      {
        fecha: new Date('2024-01-15'),
        hora: '16:00',
        estadio: 'Estadio Municipal de Madrid',
        equipoLocal: equipos[0]._id,
        equipoVisitante: equipos[1]._id,
        resultado: {
          golesLocal: 2,
          golesVisitante: 1,
          finalizado: true
        },
        estado: 'Finalizado',
        arbitro: {
          nombre: 'Roberto Sánchez',
          telefono: '911111111'
        },
        eventos: [
          {
            tipo: 'Gol',
            minuto: 25,
            jugador: jugadores[0]._id,
            equipo: equipos[0]._id,
            descripcion: 'Gol de cabeza',
            asistencia: jugadores[1]._id
          },
          {
            tipo: 'Gol',
            minuto: 67,
            jugador: jugadores[2]._id,
            equipo: equipos[1]._id,
            descripcion: 'Gol desde fuera del área'
          },
          {
            tipo: 'Gol',
            minuto: 89,
            jugador: jugadores[0]._id,
            equipo: equipos[0]._id,
            descripcion: 'Gol de penalti'
          }
        ]
      },
      {
        fecha: new Date('2024-02-20'),
        hora: '17:30',
        estadio: 'Camp Nou Amateur',
        equipoLocal: equipos[1]._id,
        equipoVisitante: equipos[2]._id,
        resultado: {
          golesLocal: 3,
          golesVisitante: 0,
          finalizado: true
        },
        estado: 'Finalizado',
        arbitro: {
          nombre: 'Miguel Torres',
          telefono: '922222222'
        },
        eventos: [
          {
            tipo: 'Gol',
            minuto: 15,
            jugador: jugadores[2]._id,
            equipo: equipos[1]._id,
            descripcion: 'Gol de tiro libre'
          },
          {
            tipo: 'Gol',
            minuto: 45,
            jugador: jugadores[2]._id,
            equipo: equipos[1]._id,
            descripcion: 'Gol de penalti'
          },
          {
            tipo: 'Gol',
            minuto: 78,
            jugador: jugadores[2]._id,
            equipo: equipos[1]._id,
            descripcion: 'Gol de contraataque'
          }
        ]
      }
    ];

    const partidos = await Partido.insertMany(partidosData);
    console.log(`✅ ${partidos.length} partidos insertados`);

    console.log('\n🎉 ¡Datos de prueba insertados correctamente!');
    console.log('\n📊 Resumen:');
    console.log(`- ${equipos.length} equipos`);
    console.log(`- ${jugadores.length} jugadores`);
    console.log(`- ${partidos.length} partidos`);
    
    console.log('\n🌐 Puedes probar estos endpoints:');
    console.log('- http://localhost:3000/api/hincha/equipos');
    console.log('- http://localhost:3000/api/hincha/tabla-posiciones');
    console.log('- http://localhost:3000/api/hincha/goleadores');
    console.log('- http://localhost:3000/api/jugadores');

  } catch (error) {
    console.error('❌ Error insertando datos:', error);
  } finally {
    mongoose.connection.close();
    console.log('🔌 Conexión cerrada');
  }
};

// Ejecutar script
const ejecutarScript = async () => {
  await connectDB();
  await insertarDatos();
};

ejecutarScript(); 