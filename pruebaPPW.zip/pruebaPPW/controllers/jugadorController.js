const Jugador = require('../models/Jugador');
const Equipo = require('../models/Equipo');
const Partido = require('../models/Partido');
const Alineacion = require('../models/Alineacion');

// @desc    Obtener todos los jugadores
// @route   GET /api/jugadores
// @access  Público
const obtenerJugadores = async (req, res) => {
  try {
    const { 
      equipo, 
      posicion, 
      estado, 
      activo = true,
      page = 1,
      limit = 10,
      sortBy = 'nombre',
      sortOrder = 'asc'
    } = req.query;

    // Construir filtros
    const filtros = { activo };
    
    if (equipo) filtros.equipo = equipo;
    if (posicion) filtros.posicion = posicion;
    if (estado) filtros.estado = estado;

    // Construir ordenamiento
    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Calcular paginación
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Ejecutar consulta
    const jugadores = await Jugador.find(filtros)
      .populate('equipo', 'nombre ciudad')
      .sort(sortOptions)
      .skip(skip)
      .limit(parseInt(limit));

    // Contar total de documentos
    const total = await Jugador.countDocuments(filtros);

    res.status(200).json({
      success: true,
      count: jugadores.length,
      total,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit))
      },
      data: jugadores
    });
  } catch (error) {
    console.error('Error al obtener jugadores:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Obtener un jugador por ID
// @route   GET /api/jugadores/:id
// @access  Público
const obtenerJugador = async (req, res) => {
  try {
    const jugador = await Jugador.findById(req.params.id)
      .populate('equipo', 'nombre ciudad estadio colores')
      .populate('condicionesMedicas');

    if (!jugador) {
      return res.status(404).json({
        success: false,
        message: 'Jugador no encontrado'
      });
    }

    res.status(200).json({
      success: true,
      data: jugador
    });
  } catch (error) {
    console.error('Error al obtener jugador:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Crear un nuevo jugador
// @route   POST /api/jugadores
// @access  Privado (Director Técnico)
const crearJugador = async (req, res) => {
  try {
    // Verificar que el equipo existe
    const equipo = await Equipo.findById(req.body.equipo);
    if (!equipo) {
      return res.status(400).json({
        success: false,
        message: 'El equipo especificado no existe'
      });
    }

    // Verificar que el DNI no esté duplicado
    const jugadorExistente = await Jugador.findOne({ dni: req.body.dni });
    if (jugadorExistente) {
      return res.status(400).json({
        success: false,
        message: 'Ya existe un jugador con ese DNI'
      });
    }

    // Verificar que el número no esté ocupado en el equipo
    const numeroOcupado = await Jugador.findOne({ 
      equipo: req.body.equipo, 
      numero: req.body.numero 
    });
    if (numeroOcupado) {
      return res.status(400).json({
        success: false,
        message: 'El número ya está ocupado por otro jugador en este equipo'
      });
    }

    const jugador = await Jugador.create(req.body);

    res.status(201).json({
      success: true,
      message: 'Jugador creado exitosamente',
      data: jugador
    });
  } catch (error) {
    console.error('Error al crear jugador:', error);
    
    if (error.name === 'ValidationError') {
      const mensajes = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: 'Error de validación',
        errors: mensajes
      });
    }

    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Actualizar un jugador
// @route   PUT /api/jugadores/:id
// @access  Privado (Director Técnico)
const actualizarJugador = async (req, res) => {
  try {
    const jugador = await Jugador.findById(req.params.id);

    if (!jugador) {
      return res.status(404).json({
        success: false,
        message: 'Jugador no encontrado'
      });
    }

    // Si se está cambiando el DNI, verificar que no esté duplicado
    if (req.body.dni && req.body.dni !== jugador.dni) {
      const jugadorExistente = await Jugador.findOne({ dni: req.body.dni });
      if (jugadorExistente) {
        return res.status(400).json({
          success: false,
          message: 'Ya existe un jugador con ese DNI'
        });
      }
    }

    // Si se está cambiando el número, verificar que no esté ocupado
    if (req.body.numero && req.body.numero !== jugador.numero) {
      const numeroOcupado = await Jugador.findOne({ 
        equipo: jugador.equipo, 
        numero: req.body.numero 
      });
      if (numeroOcupado) {
        return res.status(400).json({
          success: false,
          message: 'El número ya está ocupado por otro jugador en este equipo'
        });
      }
    }

    const jugadorActualizado = await Jugador.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    ).populate('equipo', 'nombre ciudad');

    res.status(200).json({
      success: true,
      message: 'Jugador actualizado exitosamente',
      data: jugadorActualizado
    });
  } catch (error) {
    console.error('Error al actualizar jugador:', error);
    
    if (error.name === 'ValidationError') {
      const mensajes = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: 'Error de validación',
        errors: mensajes
      });
    }

    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Eliminar un jugador (soft delete)
// @route   DELETE /api/jugadores/:id
// @access  Privado (Director Técnico)
const eliminarJugador = async (req, res) => {
  try {
    const jugador = await Jugador.findById(req.params.id);

    if (!jugador) {
      return res.status(404).json({
        success: false,
        message: 'Jugador no encontrado'
      });
    }

    // Verificar si el jugador está en alguna alineación activa
    const alineacionActiva = await Alineacion.findOne({
      'jugadores.jugador': req.params.id,
      confirmada: true,
      partido: { $in: await Partido.find({ estado: { $in: ['Programado', 'En Curso'] } }).select('_id') }
    });

    if (alineacionActiva) {
      return res.status(400).json({
        success: false,
        message: 'No se puede eliminar el jugador porque está en una alineación activa'
      });
    }

    // Soft delete
    jugador.activo = false;
    await jugador.save();

    res.status(200).json({
      success: true,
      message: 'Jugador eliminado exitosamente'
    });
  } catch (error) {
    console.error('Error al eliminar jugador:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Obtener estadísticas de un jugador
// @route   GET /api/jugadores/:id/estadisticas
// @access  Público
const obtenerEstadisticasJugador = async (req, res) => {
  try {
    const jugador = await Jugador.findById(req.params.id)
      .populate('equipo', 'nombre');

    if (!jugador) {
      return res.status(404).json({
        success: false,
        message: 'Jugador no encontrado'
      });
    }

    // Obtener partidos del jugador
    const partidos = await Partido.find({
      $or: [
        { 'eventos.jugador': req.params.id },
        { alineacionLocal: { $in: await Alineacion.find({ 'jugadores.jugador': req.params.id }).select('_id') } },
        { alineacionVisitante: { $in: await Alineacion.find({ 'jugadores.jugador': req.params.id }).select('_id') } }
      ],
      'resultado.finalizado': true
    }).populate('equipoLocal equipoVisitante', 'nombre');

    // Calcular estadísticas adicionales
    const estadisticas = {
      ...jugador.estadisticas,
      partidos: partidos.length,
      promedioGolesPorPartido: jugador.estadisticas.partidosJugados > 0 
        ? (jugador.estadisticas.goles / jugador.estadisticas.partidosJugados).toFixed(2)
        : 0,
      promedioAsistenciasPorPartido: jugador.estadisticas.partidosJugados > 0
        ? (jugador.estadisticas.asistencias / jugador.estadisticas.partidosJugados).toFixed(2)
        : 0,
      efectividad: jugador.efectividad,
      minutosPorPartido: jugador.minutosPorPartido
    };

    res.status(200).json({
      success: true,
      data: {
        jugador: {
          _id: jugador._id,
          nombre: jugador.nombre,
          apellido: jugador.apellido,
          nombreCompleto: jugador.nombreCompleto,
          edad: jugador.edad,
          posicion: jugador.posicion,
          numero: jugador.numero,
          equipo: jugador.equipo,
          estado: jugador.estado
        },
        estadisticas,
        partidos: partidos.map(p => ({
          _id: p._id,
          fecha: p.fecha,
          resultado: p.resultadoFormateado,
          equipoLocal: p.equipoLocal,
          equipoVisitante: p.equipoVisitante,
          esLocal: p.esLocal(jugador.equipo._id)
        }))
      }
    });
  } catch (error) {
    console.error('Error al obtener estadísticas del jugador:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Verificar si un jugador está en la alineación del próximo partido
// @route   GET /api/jugadores/:id/alineacion-proximo-partido
// @access  Público
const verificarAlineacionProximoPartido = async (req, res) => {
  try {
    const jugador = await Jugador.findById(req.params.id)
      .populate('equipo', 'nombre');

    if (!jugador) {
      return res.status(404).json({
        success: false,
        message: 'Jugador no encontrado'
      });
    }

    // Buscar el próximo partido del equipo
    const proximoPartido = await Partido.findOne({
      $or: [
        { equipoLocal: jugador.equipo._id },
        { equipoVisitante: jugador.equipo._id }
      ],
      estado: 'Programado',
      fecha: { $gte: new Date() }
    }).sort({ fecha: 1, hora: 1 });

    if (!proximoPartido) {
      return res.status(200).json({
        success: true,
        data: {
          jugador: {
            _id: jugador._id,
            nombre: jugador.nombreCompleto,
            equipo: jugador.equipo.nombre
          },
          proximoPartido: null,
          enAlineacion: false,
          mensaje: 'No hay partidos programados próximamente'
        }
      });
    }

    // Buscar alineación del próximo partido
    const alineacion = await Alineacion.findOne({
      partido: proximoPartido._id,
      equipo: jugador.equipo._id
    }).populate('jugadores.jugador', 'nombre apellido numero');

    const enAlineacion = alineacion ? 
      alineacion.jugadores.some(j => j.jugador._id.toString() === jugador._id.toString()) : 
      false;

    const tipoAlineacion = enAlineacion ? 
      alineacion.jugadores.find(j => j.jugador._id.toString() === jugador._id.toString())?.tipo : 
      null;

    res.status(200).json({
      success: true,
      data: {
        jugador: {
          _id: jugador._id,
          nombre: jugador.nombreCompleto,
          equipo: jugador.equipo.nombre
        },
        proximoPartido: {
          _id: proximoPartido._id,
          fecha: proximoPartido.fecha,
          hora: proximoPartido.hora,
          estadio: proximoPartido.estadio,
          equipoLocal: proximoPartido.equipoLocal,
          equipoVisitante: proximoPartido.equipoVisitante
        },
        enAlineacion,
        tipoAlineacion,
        alineacionConfirmada: alineacion ? alineacion.confirmada : false
      }
    });
  } catch (error) {
    console.error('Error al verificar alineación:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Obtener jugadores por equipo
// @route   GET /api/jugadores/equipo/:equipoId
// @access  Público
const obtenerJugadoresPorEquipo = async (req, res) => {
  try {
    const { equipoId } = req.params;
    const { posicion, estado, activo = true } = req.query;

    // Verificar que el equipo existe
    const equipo = await Equipo.findById(equipoId);
    if (!equipo) {
      return res.status(404).json({
        success: false,
        message: 'Equipo no encontrado'
      });
    }

    // Construir filtros
    const filtros = { equipo: equipoId, activo };
    if (posicion) filtros.posicion = posicion;
    if (estado) filtros.estado = estado;

    const jugadores = await Jugador.find(filtros)
      .populate('equipo', 'nombre ciudad')
      .sort({ posicion: 1, numero: 1 });

    res.status(200).json({
      success: true,
      count: jugadores.length,
      equipo: {
        _id: equipo._id,
        nombre: equipo.nombre,
        ciudad: equipo.ciudad
      },
      data: jugadores
    });
  } catch (error) {
    console.error('Error al obtener jugadores por equipo:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

module.exports = {
  obtenerJugadores,
  obtenerJugador,
  crearJugador,
  actualizarJugador,
  eliminarJugador,
  obtenerEstadisticasJugador,
  verificarAlineacionProximoPartido,
  obtenerJugadoresPorEquipo
}; 