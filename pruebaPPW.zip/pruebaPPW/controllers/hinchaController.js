const Equipo = require('../models/Equipo');
const Partido = require('../models/Partido');
const Jugador = require('../models/Jugador');
const Estadistica = require('../models/Estadistica');

// @desc    Obtener resultados de partidos
// @route   GET /api/hincha/resultados
// @access  Público
const obtenerResultados = async (req, res) => {
  try {
    const { 
      equipo, 
      fechaDesde, 
      fechaHasta, 
      estado = 'Finalizado',
      page = 1,
      limit = 10 
    } = req.query;

    // Construir filtros
    const filtros = { 'resultado.finalizado': true };
    
    if (equipo) {
      filtros.$or = [
        { equipoLocal: equipo },
        { equipoVisitante: equipo }
      ];
    }
    
    if (fechaDesde || fechaHasta) {
      filtros.fecha = {};
      if (fechaDesde) filtros.fecha.$gte = new Date(fechaDesde);
      if (fechaHasta) filtros.fecha.$lte = new Date(fechaHasta);
    }

    // Calcular paginación
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Ejecutar consulta
    const partidos = await Partido.find(filtros)
      .populate('equipoLocal', 'nombre ciudad')
      .populate('equipoVisitante', 'nombre ciudad')
      .sort({ fecha: -1, hora: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    // Contar total de documentos
    const total = await Partido.countDocuments(filtros);

    const resultados = partidos.map(partido => ({
      _id: partido._id,
      fecha: partido.fecha,
      hora: partido.hora,
      estadio: partido.estadio,
      equipoLocal: {
        _id: partido.equipoLocal._id,
        nombre: partido.equipoLocal.nombre,
        ciudad: partido.equipoLocal.ciudad,
        goles: partido.resultado.golesLocal
      },
      equipoVisitante: {
        _id: partido.equipoVisitante._id,
        nombre: partido.equipoVisitante.nombre,
        ciudad: partido.equipoVisitante.ciudad,
        goles: partido.resultado.golesVisitante
      },
      resultado: partido.resultadoFormateado,
      ganador: partido.ganador,
      tiempoExtra: partido.resultado.tiempoExtra,
      penales: partido.resultado.penales.local > 0 || partido.resultado.penales.visitante > 0 ? {
        local: partido.resultado.penales.local,
        visitante: partido.resultado.penales.visitante
      } : null
    }));

    res.status(200).json({
      success: true,
      count: resultados.length,
      total,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit))
      },
      data: resultados
    });
  } catch (error) {
    console.error('Error al obtener resultados:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Obtener tabla de posiciones
// @route   GET /api/hincha/tabla-posiciones
// @access  Público
const obtenerTablaPosiciones = async (req, res) => {
  try {
    const equipos = await Equipo.find({ activo: true })
      .select('nombre ciudad estadisticas')
      .sort({ 
        'estadisticas.puntos': -1, 
        'estadisticas.diferenciaGoles': -1,
        'estadisticas.golesFavor': -1 
      });

    const tabla = equipos.map((equipo, index) => ({
      posicion: index + 1,
      equipo: {
        _id: equipo._id,
        nombre: equipo.nombre,
        ciudad: equipo.ciudad
      },
      estadisticas: {
        partidosJugados: equipo.estadisticas.partidosJugados,
        partidosGanados: equipo.estadisticas.partidosGanados,
        partidosEmpatados: equipo.estadisticas.partidosEmpatados,
        partidosPerdidos: equipo.estadisticas.partidosPerdidos,
        golesFavor: equipo.estadisticas.golesFavor,
        golesContra: equipo.estadisticas.golesContra,
        diferenciaGoles: equipo.estadisticas.golesFavor - equipo.estadisticas.golesContra,
        puntos: equipo.estadisticas.puntos
      }
    }));

    res.status(200).json({
      success: true,
      count: tabla.length,
      data: tabla
    });
  } catch (error) {
    console.error('Error al obtener tabla de posiciones:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Obtener cuadro de goleadores
// @route   GET /api/hincha/goleadores
// @access  Público
const obtenerGoleadores = async (req, res) => {
  try {
    const { limit = 20, equipo } = req.query;

    // Construir filtros
    const filtros = { activo: true };
    if (equipo) filtros.equipo = equipo;

    const jugadores = await Jugador.find(filtros)
      .populate('equipo', 'nombre ciudad')
      .select('nombre apellido numero posicion equipo estadisticas.goles estadisticas.partidosJugados')
      .sort({ 'estadisticas.goles': -1, 'estadisticas.partidosJugados': 1 })
      .limit(parseInt(limit));

    const goleadores = jugadores
      .filter(jugador => jugador.estadisticas.goles > 0)
      .map((jugador, index) => ({
        posicion: index + 1,
        jugador: {
          _id: jugador._id,
          nombre: jugador.nombre,
          apellido: jugador.apellido,
          nombreCompleto: `${jugador.nombre} ${jugador.apellido}`,
          numero: jugador.numero,
          posicion: jugador.posicion
        },
        equipo: {
          _id: jugador.equipo._id,
          nombre: jugador.equipo.nombre,
          ciudad: jugador.equipo.ciudad
        },
        estadisticas: {
          goles: jugador.estadisticas.goles,
          partidosJugados: jugador.estadisticas.partidosJugados,
          promedioGoles: jugador.estadisticas.partidosJugados > 0 
            ? (jugador.estadisticas.goles / jugador.estadisticas.partidosJugados).toFixed(2)
            : 0
        }
      }));

    res.status(200).json({
      success: true,
      count: goleadores.length,
      data: goleadores
    });
  } catch (error) {
    console.error('Error al obtener goleadores:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Obtener cuadro de asistentes
// @route   GET /api/hincha/asistentes
// @access  Público
const obtenerAsistentes = async (req, res) => {
  try {
    const { limit = 20, equipo } = req.query;

    // Construir filtros
    const filtros = { activo: true };
    if (equipo) filtros.equipo = equipo;

    const jugadores = await Jugador.find(filtros)
      .populate('equipo', 'nombre ciudad')
      .select('nombre apellido numero posicion equipo estadisticas.asistencias estadisticas.partidosJugados')
      .sort({ 'estadisticas.asistencias': -1, 'estadisticas.partidosJugados': 1 })
      .limit(parseInt(limit));

    const asistentes = jugadores
      .filter(jugador => jugador.estadisticas.asistencias > 0)
      .map((jugador, index) => ({
        posicion: index + 1,
        jugador: {
          _id: jugador._id,
          nombre: jugador.nombre,
          apellido: jugador.apellido,
          nombreCompleto: `${jugador.nombre} ${jugador.apellido}`,
          numero: jugador.numero,
          posicion: jugador.posicion
        },
        equipo: {
          _id: jugador.equipo._id,
          nombre: jugador.equipo.nombre,
          ciudad: jugador.equipo.ciudad
        },
        estadisticas: {
          asistencias: jugador.estadisticas.asistencias,
          partidosJugados: jugador.estadisticas.partidosJugados,
          promedioAsistencias: jugador.estadisticas.partidosJugados > 0 
            ? (jugador.estadisticas.asistencias / jugador.estadisticas.partidosJugados).toFixed(2)
            : 0
        }
      }));

    res.status(200).json({
      success: true,
      count: asistentes.length,
      data: asistentes
    });
  } catch (error) {
    console.error('Error al obtener asistentes:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Obtener calendario de partidos
// @route   GET /api/hincha/calendario
// @access  Público
const obtenerCalendario = async (req, res) => {
  try {
    const { 
      equipo, 
      fechaDesde, 
      fechaHasta, 
      estado = 'Programado',
      page = 1,
      limit = 10 
    } = req.query;

    // Construir filtros
    const filtros = { estado };
    
    if (equipo) {
      filtros.$or = [
        { equipoLocal: equipo },
        { equipoVisitante: equipo }
      ];
    }
    
    if (fechaDesde || fechaHasta) {
      filtros.fecha = {};
      if (fechaDesde) filtros.fecha.$gte = new Date(fechaDesde);
      if (fechaHasta) filtros.fecha.$lte = new Date(fechaHasta);
    }

    // Calcular paginación
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Ejecutar consulta
    const partidos = await Partido.find(filtros)
      .populate('equipoLocal', 'nombre ciudad estadio')
      .populate('equipoVisitante', 'nombre ciudad')
      .sort({ fecha: 1, hora: 1 })
      .skip(skip)
      .limit(parseInt(limit));

    // Contar total de documentos
    const total = await Partido.countDocuments(filtros);

    const calendario = partidos.map(partido => ({
      _id: partido._id,
      fecha: partido.fecha,
      hora: partido.hora,
      estadio: partido.estadio,
      arbitro: partido.arbitro.nombre,
      equipoLocal: {
        _id: partido.equipoLocal._id,
        nombre: partido.equipoLocal.nombre,
        ciudad: partido.equipoLocal.ciudad
      },
      equipoVisitante: {
        _id: partido.equipoVisitante._id,
        nombre: partido.equipoVisitante.nombre,
        ciudad: partido.equipoVisitante.ciudad
      },
      estado: partido.estado,
      resultado: partido.resultado.finalizado ? partido.resultadoFormateado : 'Pendiente'
    }));

    res.status(200).json({
      success: true,
      count: calendario.length,
      total,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit))
      },
      data: calendario
    });
  } catch (error) {
    console.error('Error al obtener calendario:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Obtener información de un equipo
// @route   GET /api/hincha/equipos/:id
// @access  Público
const obtenerInformacionEquipo = async (req, res) => {
  try {
    const { id } = req.params;

    const equipo = await Equipo.findById(id);
    if (!equipo) {
      return res.status(404).json({
        success: false,
        message: 'Equipo no encontrado'
      });
    }

    // Obtener jugadores del equipo
    const jugadores = await Jugador.find({ 
      equipo: id, 
      activo: true 
    }).select('nombre apellido numero posicion estadisticas');

    // Obtener próximos partidos
    const proximosPartidos = await Partido.find({
      $or: [
        { equipoLocal: id },
        { equipoVisitante: id }
      ],
      estado: 'Programado',
      fecha: { $gte: new Date() }
    })
    .populate('equipoLocal equipoVisitante', 'nombre ciudad')
    .sort({ fecha: 1, hora: 1 })
    .limit(5);

    // Obtener últimos resultados
    const ultimosResultados = await Partido.find({
      $or: [
        { equipoLocal: id },
        { equipoVisitante: id }
      ],
      'resultado.finalizado': true
    })
    .populate('equipoLocal equipoVisitante', 'nombre ciudad')
    .sort({ fecha: -1 })
    .limit(5);

    res.status(200).json({
      success: true,
      data: {
        equipo: {
          _id: equipo._id,
          nombre: equipo.nombre,
          ciudad: equipo.ciudad,
          fundacion: equipo.fundacion,
          colores: equipo.colores,
          estadio: equipo.estadio,
          directorTecnico: equipo.directorTecnico
        },
        estadisticas: {
          ...equipo.estadisticas,
          diferenciaGoles: equipo.estadisticas.golesFavor - equipo.estadisticas.golesContra,
          porcentajeVictorias: equipo.estadisticas.partidosJugados > 0 
            ? ((equipo.estadisticas.partidosGanados / equipo.estadisticas.partidosJugados) * 100).toFixed(2)
            : 0
        },
        jugadores: {
          total: jugadores.length,
          porPosicion: {
            Portero: jugadores.filter(j => j.posicion === 'Portero').length,
            Defensa: jugadores.filter(j => j.posicion === 'Defensa').length,
            Mediocampista: jugadores.filter(j => j.posicion === 'Mediocampista').length,
            Delantero: jugadores.filter(j => j.posicion === 'Delantero').length
          }
        },
        proximosPartidos: proximosPartidos.map(p => ({
          _id: p._id,
          fecha: p.fecha,
          hora: p.hora,
          estadio: p.estadio,
          equipoLocal: p.equipoLocal,
          equipoVisitante: p.equipoVisitante,
          esLocal: p.equipoLocal._id.toString() === id
        })),
        ultimosResultados: ultimosResultados.map(p => ({
          _id: p._id,
          fecha: p.fecha,
          resultado: p.resultadoFormateado,
          equipoLocal: p.equipoLocal,
          equipoVisitante: p.equipoVisitante,
          esLocal: p.equipoLocal._id.toString() === id,
          ganador: p.ganador
        }))
      }
    });
  } catch (error) {
    console.error('Error al obtener información del equipo:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Obtener todos los equipos
// @route   GET /api/hincha/equipos
// @access  Público
const obtenerEquipos = async (req, res) => {
  try {
    const { ciudad, activo = true } = req.query;

    // Construir filtros
    const filtros = { activo };
    if (ciudad) filtros.ciudad = new RegExp(ciudad, 'i');

    const equipos = await Equipo.find(filtros)
      .select('nombre ciudad estadio colores estadisticas')
      .sort({ nombre: 1 });

    const equiposFormateados = equipos.map(equipo => ({
      _id: equipo._id,
      nombre: equipo.nombre,
      ciudad: equipo.ciudad,
      estadio: equipo.estadio,
      colores: equipo.colores,
      estadisticas: {
        partidosJugados: equipo.estadisticas.partidosJugados,
        puntos: equipo.estadisticas.puntos,
        posicion: 0 // Se calculará después
      }
    }));

    // Ordenar por puntos para calcular posiciones
    equiposFormateados.sort((a, b) => b.estadisticas.puntos - a.estadisticas.puntos);
    
    // Asignar posiciones
    equiposFormateados.forEach((equipo, index) => {
      equipo.estadisticas.posicion = index + 1;
    });

    res.status(200).json({
      success: true,
      count: equiposFormateados.length,
      data: equiposFormateados
    });
  } catch (error) {
    console.error('Error al obtener equipos:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

module.exports = {
  obtenerResultados,
  obtenerTablaPosiciones,
  obtenerGoleadores,
  obtenerAsistentes,
  obtenerCalendario,
  obtenerInformacionEquipo,
  obtenerEquipos
}; 