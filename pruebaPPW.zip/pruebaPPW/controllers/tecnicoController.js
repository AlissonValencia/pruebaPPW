const Jugador = require('../models/Jugador');
const Equipo = require('../models/Equipo');
const Partido = require('../models/Partido');
const Alineacion = require('../models/Alineacion');
const Estadistica = require('../models/Estadistica');

// @desc    Obtener tabla de posiciones
// @route   GET /api/tecnico/tabla-posiciones
// @access  Privado (Director Técnico)
const obtenerTablaPosiciones = async (req, res) => {
  try {
    const equipos = await Equipo.find({ activo: true })
      .select('nombre ciudad estadisticas')
      .sort({ 
        'estadisticas.puntos': -1, 
        'estadisticas.diferenciaGoles': -1,
        'estadisticas.golesFavor': -1 
      });

    const tabla = equipos.map((equipo, index) => ({
      posicion: index + 1,
      equipo: {
        _id: equipo._id,
        nombre: equipo.nombre,
        ciudad: equipo.ciudad
      },
      estadisticas: {
        ...equipo.estadisticas,
        diferenciaGoles: equipo.estadisticas.golesFavor - equipo.estadisticas.golesContra
      }
    }));

    res.status(200).json({
      success: true,
      count: tabla.length,
      data: tabla
    });
  } catch (error) {
    console.error('Error al obtener tabla de posiciones:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Obtener estadísticas por equipo
// @route   GET /api/tecnico/estadisticas-equipo/:equipoId
// @access  Privado (Director Técnico)
const obtenerEstadisticasEquipo = async (req, res) => {
  try {
    const { equipoId } = req.params;
    const { temporada } = req.query;

    const equipo = await Equipo.findById(equipoId);
    if (!equipo) {
      return res.status(404).json({
        success: false,
        message: 'Equipo no encontrado'
      });
    }

    // Obtener jugadores del equipo
    const jugadores = await Jugador.find({ 
      equipo: equipoId, 
      activo: true 
    }).select('nombre apellido posicion estadisticas');

    // Obtener partidos del equipo
    const partidos = await Partido.find({
      $or: [
        { equipoLocal: equipoId },
        { equipoVisitante: equipoId }
      ],
      'resultado.finalizado': true
    }).populate('equipoLocal equipoVisitante', 'nombre');

    // Calcular estadísticas adicionales
    const estadisticasEquipo = {
      ...equipo.estadisticas,
      diferenciaGoles: equipo.estadisticas.golesFavor - equipo.estadisticas.golesContra,
      porcentajeVictorias: equipo.estadisticas.partidosJugados > 0 
        ? ((equipo.estadisticas.partidosGanados / equipo.estadisticas.partidosJugados) * 100).toFixed(2)
        : 0,
      promedioGolesPorPartido: equipo.estadisticas.partidosJugados > 0
        ? (equipo.estadisticas.golesFavor / equipo.estadisticas.partidosJugados).toFixed(2)
        : 0,
      promedioGolesContraPorPartido: equipo.estadisticas.partidosJugados > 0
        ? (equipo.estadisticas.golesContra / equipo.estadisticas.partidosJugados).toFixed(2)
        : 0
    };

    // Estadísticas por posición
    const estadisticasPorPosicion = {
      Portero: { jugadores: 0, goles: 0, asistencias: 0, tarjetasAmarillas: 0, tarjetasRojas: 0 },
      Defensa: { jugadores: 0, goles: 0, asistencias: 0, tarjetasAmarillas: 0, tarjetasRojas: 0 },
      Mediocampista: { jugadores: 0, goles: 0, asistencias: 0, tarjetasAmarillas: 0, tarjetasRojas: 0 },
      Delantero: { jugadores: 0, goles: 0, asistencias: 0, tarjetasAmarillas: 0, tarjetasRojas: 0 }
    };

    jugadores.forEach(jugador => {
      const pos = estadisticasPorPosicion[jugador.posicion];
      if (pos) {
        pos.jugadores++;
        pos.goles += jugador.estadisticas.goles;
        pos.asistencias += jugador.estadisticas.asistencias;
        pos.tarjetasAmarillas += jugador.estadisticas.tarjetasAmarillas;
        pos.tarjetasRojas += jugador.estadisticas.tarjetasRojas;
      }
    });

    res.status(200).json({
      success: true,
      data: {
        equipo: {
          _id: equipo._id,
          nombre: equipo.nombre,
          ciudad: equipo.ciudad
        },
        estadisticas: estadisticasEquipo,
        jugadores: {
          total: jugadores.length,
          porPosicion: estadisticasPorPosicion
        },
        partidos: {
          total: partidos.length,
          resumen: partidos.map(p => ({
            _id: p._id,
            fecha: p.fecha,
            resultado: p.resultadoFormateado,
            equipoLocal: p.equipoLocal.nombre,
            equipoVisitante: p.equipoVisitante.nombre,
            esLocal: p.equipoLocal._id.toString() === equipoId
          }))
        }
      }
    });
  } catch (error) {
    console.error('Error al obtener estadísticas del equipo:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Registrar gol en partido
// @route   POST /api/tecnico/partidos/:partidoId/goles
// @access  Privado (Director Técnico)
const registrarGol = async (req, res) => {
  try {
    const { partidoId } = req.params;
    const { jugadorId, asistenciaId, minuto, descripcion, equipoId } = req.body;

    const partido = await Partido.findById(partidoId);
    if (!partido) {
      return res.status(404).json({
        success: false,
        message: 'Partido no encontrado'
      });
    }

    if (partido.resultado.finalizado) {
      return res.status(400).json({
        success: false,
        message: 'No se pueden registrar goles en un partido finalizado'
      });
    }

    // Verificar que el jugador pertenece al equipo
    const jugador = await Jugador.findById(jugadorId);
    if (!jugador || jugador.equipo.toString() !== equipoId) {
      return res.status(400).json({
        success: false,
        message: 'El jugador no pertenece al equipo especificado'
      });
    }

    // Verificar que el asistente pertenece al mismo equipo
    if (asistenciaId) {
      const asistente = await Jugador.findById(asistenciaId);
      if (!asistente || asistente.equipo.toString() !== equipoId) {
        return res.status(400).json({
          success: false,
          message: 'El asistente no pertenece al equipo especificado'
        });
      }
    }

    // Agregar evento de gol
    const eventoGol = {
      tipo: 'Gol',
      minuto: parseInt(minuto),
      jugador: jugadorId,
      equipo: equipoId,
      descripcion: descripcion || 'Gol',
      asistencia: asistenciaId
    };

    partido.eventos.push(eventoGol);

    // Actualizar resultado del partido
    if (partido.equipoLocal.toString() === equipoId) {
      partido.resultado.golesLocal++;
    } else if (partido.equipoVisitante.toString() === equipoId) {
      partido.resultado.golesVisitante++;
    }

    await partido.save();

    // Actualizar estadísticas del jugador
    jugador.estadisticas.goles++;
    await jugador.save();

    // Actualizar estadísticas del asistente
    if (asistenciaId) {
      const asistente = await Jugador.findById(asistenciaId);
      asistente.estadisticas.asistencias++;
      await asistente.save();
    }

    res.status(200).json({
      success: true,
      message: 'Gol registrado exitosamente',
      data: {
        partido: partido._id,
        evento: eventoGol
      }
    });
  } catch (error) {
    console.error('Error al registrar gol:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Registrar tarjeta en partido
// @route   POST /api/tecnico/partidos/:partidoId/tarjetas
// @access  Privado (Director Técnico)
const registrarTarjeta = async (req, res) => {
  try {
    const { partidoId } = req.params;
    const { jugadorId, tipo, minuto, motivo, equipoId } = req.body;

    const partido = await Partido.findById(partidoId);
    if (!partido) {
      return res.status(404).json({
        success: false,
        message: 'Partido no encontrado'
      });
    }

    if (partido.resultado.finalizado) {
      return res.status(400).json({
        success: false,
        message: 'No se pueden registrar tarjetas en un partido finalizado'
      });
    }

    // Verificar que el jugador pertenece al equipo
    const jugador = await Jugador.findById(jugadorId);
    if (!jugador || jugador.equipo.toString() !== equipoId) {
      return res.status(400).json({
        success: false,
        message: 'El jugador no pertenece al equipo especificado'
      });
    }

    // Agregar evento de tarjeta
    const eventoTarjeta = {
      tipo,
      minuto: parseInt(minuto),
      jugador: jugadorId,
      equipo: equipoId,
      descripcion: `${tipo} - ${motivo || 'Sin especificar'}`,
      motivo: motivo || 'Sin especificar'
    };

    partido.eventos.push(eventoTarjeta);

    // Actualizar estadísticas del jugador
    if (tipo === 'Tarjeta Amarilla') {
      jugador.estadisticas.tarjetasAmarillas++;
    } else if (tipo === 'Tarjeta Roja' || tipo === 'Tarjeta Roja Directa') {
      jugador.estadisticas.tarjetasRojas++;
      if (tipo === 'Tarjeta Roja Directa') {
        jugador.estadisticas.tarjetasRojasDirectas++;
      }
    }

    await jugador.save();
    await partido.save();

    res.status(200).json({
      success: true,
      message: 'Tarjeta registrada exitosamente',
      data: {
        partido: partido._id,
        evento: eventoTarjeta
      }
    });
  } catch (error) {
    console.error('Error al registrar tarjeta:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Crear alineación para partido
// @route   POST /api/tecnico/alineaciones
// @access  Privado (Director Técnico)
const crearAlineacion = async (req, res) => {
  try {
    const { 
      partidoId, 
      equipoId, 
      formacion, 
      jugadores, 
      directorTecnico,
      observaciones 
    } = req.body;

    // Verificar que el partido existe
    const partido = await Partido.findById(partidoId);
    if (!partido) {
      return res.status(404).json({
        success: false,
        message: 'Partido no encontrado'
      });
    }

    // Verificar que el equipo participa en el partido
    if (partido.equipoLocal.toString() !== equipoId && partido.equipoVisitante.toString() !== equipoId) {
      return res.status(400).json({
        success: false,
        message: 'El equipo no participa en este partido'
      });
    }

    // Verificar que no existe ya una alineación para este equipo en este partido
    const alineacionExistente = await Alineacion.findOne({
      partido: partidoId,
      equipo: equipoId
    });

    if (alineacionExistente) {
      return res.status(400).json({
        success: false,
        message: 'Ya existe una alineación para este equipo en este partido'
      });
    }

    // Verificar que todos los jugadores pertenecen al equipo
    const jugadoresIds = jugadores.map(j => j.jugador);
    const jugadoresEquipo = await Jugador.find({
      _id: { $in: jugadoresIds },
      equipo: equipoId,
      activo: true
    });

    if (jugadoresEquipo.length !== jugadoresIds.length) {
      return res.status(400).json({
        success: false,
        message: 'Algunos jugadores no pertenecen al equipo o no están activos'
      });
    }

    // Crear la alineación
    const alineacion = new Alineacion({
      partido: partidoId,
      equipo: equipoId,
      formacion,
      jugadores: jugadores.map((j, index) => ({
        ...j,
        orden: index + 1
      })),
      directorTecnico,
      observaciones
    });

    await alineacion.save();

    // Actualizar el partido con la referencia a la alineación
    if (partido.equipoLocal.toString() === equipoId) {
      partido.alineacionLocal = alineacion._id;
    } else {
      partido.alineacionVisitante = alineacion._id;
    }
    await partido.save();

    res.status(201).json({
      success: true,
      message: 'Alineación creada exitosamente',
      data: alineacion
    });
  } catch (error) {
    console.error('Error al crear alineación:', error);
    
    if (error.name === 'ValidationError') {
      const mensajes = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: 'Error de validación',
        errors: mensajes
      });
    }

    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Actualizar alineación
// @route   PUT /api/tecnico/alineaciones/:id
// @access  Privado (Director Técnico)
const actualizarAlineacion = async (req, res) => {
  try {
    const { id } = req.params;
    const { jugadores, formacion, observaciones } = req.body;

    const alineacion = await Alineacion.findById(id);
    if (!alineacion) {
      return res.status(404).json({
        success: false,
        message: 'Alineación no encontrada'
      });
    }

    if (alineacion.confirmada) {
      return res.status(400).json({
        success: false,
        message: 'No se puede modificar una alineación confirmada'
      });
    }

    // Actualizar jugadores si se proporcionan
    if (jugadores) {
      alineacion.jugadores = jugadores.map((j, index) => ({
        ...j,
        orden: index + 1
      }));
    }

    if (formacion) alineacion.formacion = formacion;
    if (observaciones) alineacion.observaciones = observaciones;

    await alineacion.save();

    res.status(200).json({
      success: true,
      message: 'Alineación actualizada exitosamente',
      data: alineacion
    });
  } catch (error) {
    console.error('Error al actualizar alineación:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Confirmar alineación
// @route   POST /api/tecnico/alineaciones/:id/confirmar
// @access  Privado (Director Técnico)
const confirmarAlineacion = async (req, res) => {
  try {
    const { id } = req.params;

    const alineacion = await Alineacion.findById(id);
    if (!alineacion) {
      return res.status(404).json({
        success: false,
        message: 'Alineación no encontrada'
      });
    }

    if (alineacion.confirmada) {
      return res.status(400).json({
        success: false,
        message: 'La alineación ya está confirmada'
      });
    }

    // Verificar que hay al menos 11 titulares
    const titulares = alineacion.jugadores.filter(j => j.tipo === 'Titular');
    if (titulares.length < 11) {
      return res.status(400).json({
        success: false,
        message: 'Debe haber al menos 11 titulares para confirmar la alineación'
      });
    }

    alineacion.confirmada = true;
    alineacion.fechaConfirmacion = new Date();
    await alineacion.save();

    res.status(200).json({
      success: true,
      message: 'Alineación confirmada exitosamente',
      data: alineacion
    });
  } catch (error) {
    console.error('Error al confirmar alineación:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

// @desc    Obtener alineación por partido y equipo
// @route   GET /api/tecnico/alineaciones/partido/:partidoId/equipo/:equipoId
// @access  Privado (Director Técnico)
const obtenerAlineacion = async (req, res) => {
  try {
    const { partidoId, equipoId } = req.params;

    const alineacion = await Alineacion.findOne({
      partido: partidoId,
      equipo: equipoId
    }).populate('jugadores.jugador', 'nombre apellido numero posicion');

    if (!alineacion) {
      return res.status(404).json({
        success: false,
        message: 'Alineación no encontrada'
      });
    }

    res.status(200).json({
      success: true,
      data: alineacion
    });
  } catch (error) {
    console.error('Error al obtener alineación:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor',
      error: error.message
    });
  }
};

module.exports = {
  obtenerTablaPosiciones,
  obtenerEstadisticasEquipo,
  registrarGol,
  registrarTarjeta,
  crearAlineacion,
  actualizarAlineacion,
  confirmarAlineacion,
  obtenerAlineacion
}; 