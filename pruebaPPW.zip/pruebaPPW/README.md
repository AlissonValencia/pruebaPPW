# ⚽ UpScore - API de Gestión Deportiva

Backend completo para una aplicación de gestión deportiva de fútbol amateur desarrollado con Node.js, Express y MongoDB.

## 🚀 Características

### 👟 Jugadores
- Consultar estadísticas personales (goles, tarjetas, lesiones, calificaciones)
- Verificar si está en la alineación del próximo partido
- Gestión completa de perfiles deportivos

### 🧑‍💼 Directores Técnicos
- Crear, editar y eliminar jugadores
- Registrar goles, tarjetas y asistencias por partido
- Gestionar alineaciones para partidos
- Ver tabla de posiciones y estadísticas por equipo

### ⚽ Hinchas
- Consultar resultados de partidos
- Ver tabla de posiciones
- Acceder a cuadro de goleadores y asistentes
- Consultar calendario de partidos

## 🛠️ Tecnologías Utilizadas

- **Node.js** - Runtime de JavaScript
- **Express.js** - Framework web
- **MongoDB** - Base de datos NoSQL
- **Mongoose** - ODM para MongoDB
- **dotenv** - Variables de entorno
- **Helmet** - Seguridad
- **CORS** - Cross-Origin Resource Sharing
- **Rate Limiting** - Protección contra spam

## 📁 Estructura del Proyecto

```
upscore-backend/
│
├── controllers/          # Lógica de negocio
│   ├── jugadorController.js
│   ├── tecnicoController.js
│   └── hinchaController.js
│
├── models/              # Modelos de datos
│   ├── Jugador.js
│   ├── Equipo.js
│   ├── Partido.js
│   ├── Alineacion.js
│   └── Estadistica.js
│
├── routes/              # Rutas de la API
│   ├── jugadorRoutes.js
│   ├── tecnicoRoutes.js
│   └── hinchaRoutes.js
│
├── config/              # Configuración
│   └── db.js
│
├── .env                 # Variables de entorno
├── server.js           # Punto de entrada
├── package.json
└── README.md
```

## 🚀 Instalación

### Prerrequisitos

- Node.js (v14 o superior)
- MongoDB (v4.4 o superior)
- npm o yarn

### Pasos de instalación

1. **Clonar el repositorio**
   ```bash
   git clone <url-del-repositorio>
   cd upscore-backend
   ```

2. **Instalar dependencias**
   ```bash
   npm install
   ```

3. **Configurar variables de entorno**
   ```bash
   cp env.example .env
   ```
   
   Editar el archivo `.env` con tus configuraciones:
   ```env
   PORT=3000
   NODE_ENV=development
   MONGODB_URI=mongodb://localhost:27017/upscore
   JWT_SECRET=tu_jwt_secret_super_seguro_aqui
   JWT_EXPIRE=24h
   RATE_LIMIT_WINDOW_MS=900000
   RATE_LIMIT_MAX_REQUESTS=100
   ```

4. **Iniciar MongoDB**
   ```bash
   # En Windows
   net start MongoDB
   
   # En macOS/Linux
   sudo systemctl start mongod
   ```

5. **Ejecutar el servidor**
   ```bash
   # Desarrollo
   npm run dev
   
   # Producción
   npm start
   ```

## 📚 API Endpoints

### 🏠 Base URL
```
http://localhost:3000
```

### 👟 Jugadores (`/api/jugadores`)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/` | Obtener todos los jugadores |
| GET | `/:id` | Obtener jugador por ID |
| GET | `/:id/estadisticas` | Obtener estadísticas del jugador |
| GET | `/:id/alineacion-proximo-partido` | Verificar alineación |
| GET | `/equipo/:equipoId` | Obtener jugadores por equipo |
| POST | `/` | Crear nuevo jugador |
| PUT | `/:id` | Actualizar jugador |
| DELETE | `/:id` | Eliminar jugador |

### 🧑‍💼 Técnicos (`/api/tecnico`)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/tabla-posiciones` | Obtener tabla de posiciones |
| GET | `/estadisticas-equipo/:equipoId` | Estadísticas por equipo |
| POST | `/partidos/:partidoId/goles` | Registrar gol |
| POST | `/partidos/:partidoId/tarjetas` | Registrar tarjeta |
| POST | `/alineaciones` | Crear alineación |
| PUT | `/alineaciones/:id` | Actualizar alineación |
| POST | `/alineaciones/:id/confirmar` | Confirmar alineación |
| GET | `/alineaciones/partido/:partidoId/equipo/:equipoId` | Obtener alineación |

### ⚽ Hinchas (`/api/hincha`)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/resultados` | Obtener resultados de partidos |
| GET | `/tabla-posiciones` | Obtener tabla de posiciones |
| GET | `/goleadores` | Obtener cuadro de goleadores |
| GET | `/asistentes` | Obtener cuadro de asistentes |
| GET | `/calendario` | Obtener calendario de partidos |
| GET | `/equipos` | Obtener todos los equipos |
| GET | `/equipos/:id` | Obtener información de equipo |

## 📊 Modelos de Datos

### Jugador
```javascript
{
  nombre: String,
  apellido: String,
  fechaNacimiento: Date,
  dni: String (único),
  telefono: String,
  email: String,
  direccion: String,
  posicion: ['Portero', 'Defensa', 'Mediocampista', 'Delantero'],
  numero: Number,
  equipo: ObjectId (ref: 'Equipo'),
  estado: ['Activo', 'Lesionado', 'Suspendido', 'Inactivo'],
  estadisticas: {
    partidosJugados: Number,
    goles: Number,
    asistencias: Number,
    tarjetasAmarillas: Number,
    tarjetasRojas: Number,
    // ... más campos
  }
}
```

### Equipo
```javascript
{
  nombre: String,
  ciudad: String,
  fundacion: Date,
  colores: {
    principal: String,
    secundario: String
  },
  estadio: {
    nombre: String,
    capacidad: Number
  },
  directorTecnico: {
    nombre: String,
    telefono: String,
    email: String
  },
  estadisticas: {
    partidosJugados: Number,
    partidosGanados: Number,
    puntos: Number,
    // ... más campos
  }
}
```

### Partido
```javascript
{
  fecha: Date,
  hora: String,
  estadio: String,
  equipoLocal: ObjectId (ref: 'Equipo'),
  equipoVisitante: ObjectId (ref: 'Equipo'),
  resultado: {
    golesLocal: Number,
    golesVisitante: Number,
    finalizado: Boolean
  },
  estado: ['Programado', 'En Curso', 'Finalizado', 'Cancelado'],
  eventos: [{
    tipo: String,
    minuto: Number,
    jugador: ObjectId,
    // ... más campos
  }]
}
```

## 🔧 Configuración

### Variables de Entorno

| Variable | Descripción | Valor por defecto |
|----------|-------------|-------------------|
| `PORT` | Puerto del servidor | 3000 |
| `NODE_ENV` | Ambiente de ejecución | development |
| `MONGODB_URI` | URI de conexión a MongoDB | mongodb://localhost:27017/upscore |
| `JWT_SECRET` | Clave secreta para JWT | - |
| `JWT_EXPIRE` | Tiempo de expiración JWT | 24h |
| `RATE_LIMIT_WINDOW_MS` | Ventana de rate limiting | 900000 (15 min) |
| `RATE_LIMIT_MAX_REQUESTS` | Máximo de requests | 100 |

### Scripts Disponibles

```json
{
  "start": "node server.js",
  "dev": "nodemon server.js",
  "test": "echo \"Error: no test specified\" && exit 1"
}
```

## 🛡️ Seguridad

- **Helmet**: Headers de seguridad
- **CORS**: Configuración de orígenes permitidos
- **Rate Limiting**: Protección contra spam
- **Validación de datos**: Validación con Mongoose
- **Sanitización**: Limpieza de datos de entrada

## 📈 Características Avanzadas

### Estadísticas Automáticas
- Cálculo automático de posiciones en tabla
- Estadísticas por jugador y equipo
- Promedios y porcentajes automáticos

### Gestión de Alineaciones
- Creación y confirmación de alineaciones
- Validación de jugadores por equipo
- Control de titulares y suplentes

### Eventos de Partido
- Registro de goles con asistencias
- Control de tarjetas amarillas y rojas
- Historial completo de eventos

## 🧪 Testing

Para ejecutar las pruebas (cuando se implementen):

```bash
npm test
```

## 📝 Ejemplos de Uso

### Crear un jugador
```bash
curl -X POST http://localhost:3000/api/jugadores \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Lionel",
    "apellido": "Messi",
    "fechaNacimiento": "1987-06-24",
    "dni": "12345678",
    "telefono": "123456789",
    "email": "messi@example.com",
    "direccion": "Barcelona, España",
    "posicion": "Delantero",
    "numero": 10,
    "equipo": "equipoId",
    "contactoEmergencia": {
      "nombre": "Antonela Roccuzzo",
      "relacion": "Esposa",
      "telefono": "987654321"
    }
  }'
```

### Obtener tabla de posiciones
```bash
curl http://localhost:3000/api/hincha/tabla-posiciones
```

### Registrar un gol
```bash
curl -X POST http://localhost:3000/api/tecnico/partidos/partidoId/goles \
  -H "Content-Type: application/json" \
  -d '{
    "jugadorId": "jugadorId",
    "asistenciaId": "asistenteId",
    "minuto": 45,
    "descripcion": "Golazo desde fuera del área",
    "equipoId": "equipoId"
  }'
```

## 🤝 Contribución

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para detalles.

## 👥 Autores

- **Tu Nombre** - *Desarrollo inicial* - [TuUsuario](https://github.com/TuUsuario)

## 🙏 Agradecimientos

- Comunidad de Node.js
- Documentación de Express.js
- Tutoriales de MongoDB y Mongoose

## 📞 Soporte

Si tienes alguna pregunta o necesitas ayuda:

- 📧 Email: tu-email@example.com
- 🐛 Issues: [GitHub Issues](https://github.com/TuUsuario/upscore-backend/issues)
- 📖 Documentación: [Wiki del proyecto](https://github.com/TuUsuario/upscore-backend/wiki)

---

**¡Disfruta gestionando tu liga de fútbol amateur! ⚽🏆** 